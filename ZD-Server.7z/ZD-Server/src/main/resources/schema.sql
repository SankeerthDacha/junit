DROP TABLE IF EXISTS TRX_ZIP_TO_DEST;

create table TRX_ZIP_TO_DEST
( 
      NETWORK varchar(5) not null, 
      COUNTRY_CD numeric(3) not null,
      ZIP_CD varchar(11) NOT NULL,
      STATE char(2) NOT NULL,
      DEST_TERMINAL numeric(10) NOT NULL,
      CREATION_DATE_TMSTP timestamp,
      CREATION_USER varchar(32),
      CANCELLED_USER varchar(32),
      EFFECTIVE_DATE_TMSTP timestamp,
      CANCELLED_DATE_TMSTP timestamp,
      PROCESSED_FLG char(1) NOT NULL,
 	  CURRENT_FLG char(1) NOT NULL,
 	  CANCELLED_FLG char(1), 
 	  UUID varchar(40),
 	  TRANS_TYPE char(1) NOT NULL,
 	  
    primary key(NETWORK,COUNTRY_CD,ZIP_CD,CREATION_DATE_TMSTP)
);