package com.fedex.ziptodest.server.service.impl;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.uuid.Generators;
import com.fedex.ziptodest.server.exception.ApplicationException;
import com.fedex.ziptodest.server.model.ZipToDest;
import com.fedex.ziptodest.server.model.ZipToDestAddRequest;
import com.fedex.ziptodest.server.model.ZipToDestCancelRequest;
import com.fedex.ziptodest.server.model.ZipToDestDeleteRequest;
import com.fedex.ziptodest.server.model.ZipToDestModifyRequest;
import com.fedex.ziptodest.server.model.ZipToDestNotProcessed;
import com.fedex.ziptodest.server.repository.ZipToDestRepository;
import com.fedex.ziptodest.server.service.ZDService;
import com.fedex.ziptodest.server.utils.ValidationUtil;
import com.fedex.ziptodest.server.utils.ZipToDestConstants;

@Service
@Transactional("serverTransactionManager")
public class ZDServiceImpl implements ZDService {

	public static final Logger log = LoggerFactory.getLogger(ZDServiceImpl.class);

	@Autowired
	private ZipToDestRepository zipToDestRepository;

	@Autowired
	private ValidationUtil validationUtil;

	@Override
	public List<ZipToDest> getAllZDRecord() {
		return zipToDestRepository.findAll(Sort.by("zipCode"));
	}

	@Override
	public ZipToDest addZDRecord(ZipToDestAddRequest zipToDestAddRequest) throws ParseException {
		try {
			UUID uuid = Generators.timeBasedGenerator().generate();
			ZipToDest zipToDest = setZipToDestAddRequestToZipToDest(zipToDestAddRequest);
			zipToDest.setUuid(uuid.toString());
			return zipToDestRepository.save(zipToDest);
		} catch (Exception exception) {
			log.error("ZDServiceImpl - Records are not saved");
			throw new ApplicationException(exception);
		}
	}

	public String modifyRecords(ZipToDestModifyRequest zipToDestModifyRequest) throws ParseException {

		ZipToDest zipToDest = new ZipToDest();
		String effectiveDate = zipToDestModifyRequest.getEffectiveDate();

		String checkDateFormat = validationUtil.isDateFormatValid(effectiveDate);
		if (!(checkDateFormat.equals(ZipToDestConstants.VALID))) {
			log.debug("ZDServiceImpl : Invalid date format");
			return checkDateFormat;
		}

		zipToDest.setEffectiveDate(validationUtil.convertDateToTimeStamp(effectiveDate));
		zipToDest.setNetwork(zipToDestModifyRequest.getNetwork());
		zipToDest.setDestinationTerminal(zipToDestModifyRequest.getDestinationTerminal());
		String zipFrom = zipToDestModifyRequest.getZipFrom();
		String zipTo = zipToDestModifyRequest.getZipTo();
		if (validationUtil.isValidUsaZipCode(zipFrom.trim())) {
			zipFrom = StringUtils.rightPad(zipFrom, 11, '0');
		}
		if (validationUtil.isValidUsaZipCode(zipTo.trim())) {
			zipTo = StringUtils.rightPad(zipTo, 11, '0');
		}
		zipToDest.setZipFrom(zipFrom);
		zipToDest.setZipTo(zipTo);
		zipToDest.setTimeZone(zipToDestModifyRequest.getTimeZone());
		return (validationUtil.isValidDestination(zipToDestModifyRequest.getDestinationTerminal()))
				? updateZDRecord(zipToDest)
				: ZipToDestConstants.INVALID_DESTINATION;

	}

	public String deleteRecords(ZipToDestDeleteRequest zipToDestDeleteRequest) throws ParseException {

		ZipToDest zipToDest = new ZipToDest();
		String effectiveDate = zipToDestDeleteRequest.getEffectiveDate();
		String checkDateFormat = validationUtil.isDateFormatValid(effectiveDate);
		if (!(checkDateFormat.equals(ZipToDestConstants.VALID))) {
			log.debug("ZDServiceImpl : Invalid date format");
			return checkDateFormat;
		}
		zipToDest.setEffectiveDate(validationUtil.convertDateToTimeStamp(effectiveDate));
		zipToDest.setNetwork(zipToDestDeleteRequest.getNetwork().trim());

		String zipFrom = zipToDestDeleteRequest.getZipFrom();
		String zipTo = zipToDestDeleteRequest.getZipTo();
		if (validationUtil.isValidUsaZipCode(zipFrom.trim())) {
			zipFrom = StringUtils.rightPad(zipFrom, 11, '0');
		}
		if (validationUtil.isValidUsaZipCode(zipTo.trim())) {
			zipTo = StringUtils.rightPad(zipTo, 11, '0');
		}

		zipToDest.setZipFrom(zipFrom);
		zipToDest.setZipTo(zipTo);
		zipToDest.setTimeZone(zipToDestDeleteRequest.getTimeZone());
		return updateZDRecord(zipToDest);
	}

	private String updateZDRecord(ZipToDest zipToDest) {
		log.info("ZDServiceImpl : called updateZDRecord");
		String message = StringUtils.EMPTY;
		if (!isRecordsAreProcessed(zipToDest)) {
			message = ZipToDestConstants.RECORDS_NOT_PROCESSED;
			log.debug("ZDServiceImpl : Invalid zip codes or The zip codes are not processed yet)");
			return message;
		}

		List<ZipToDest> listOfMatchedRecords = zipToDestRepository.findProcessedZipcodeBetweenTwoRange(
				zipToDest.getZipFrom(), zipToDest.getZipTo(), zipToDest.getNetwork().trim());

		UUID uuid = Generators.timeBasedGenerator().generate();
		prepareNewZipToDestRecords(listOfMatchedRecords, zipToDest, uuid);
		message = ZipToDestConstants.RESPONSE_SUCCESS_MSG;

		log.info("ZDServiceImpl : Records are updated successfully");
		return message;
	}

	private boolean isRecordsAreProcessed(ZipToDest zipToDest) {
		log.info("ZDServiceImpl : Validate ProcessedRecords");
		List<ZipToDest> processedRecords;
		String zipFrom = zipToDest.getZipFrom().trim();
		String zipTo = zipToDest.getZipTo().trim();
		String network = zipToDest.getNetwork().trim();

		if (!zipFrom.isEmpty() && !zipTo.isEmpty()) {
			processedRecords = zipToDestRepository.findProcessedZipcodeBetweenTwoRange(zipFrom, zipTo, network);
			return processedRecords.isEmpty() ? false : true;
		}
		log.debug("ZDServiceImpl : Records are not processed");
		return false;
	}

	/**
	 * 
	 * @param listOfMactchedRecord list of matched records
	 * @param zipToDest            updated list of record
	 * @param uuid                 unique id to add each records
	 * @return list of updated records
	 */
	private void prepareNewZipToDestRecords(List<ZipToDest> listOfMactchedRecords, ZipToDest zipToDest, UUID uuid) {
		try {
			listOfMactchedRecords.stream().forEach(listOfMactchedRecord -> {
				ZipToDest newZipToDest = new ZipToDest();
				newZipToDest.setNetwork(listOfMactchedRecord.getNetwork().trim());
				newZipToDest.setCountryCode(listOfMactchedRecord.getCountryCode());
				newZipToDest.setZipCode(listOfMactchedRecord.getZipCode());
				newZipToDest.setState(listOfMactchedRecord.getState());
				newZipToDest.setCreationDate(new Timestamp(System.currentTimeMillis()));
				newZipToDest.setCreationUser(listOfMactchedRecord.getCreationUser());
				newZipToDest.setEffectiveDate(convertDateTime(zipToDest.getEffectiveDate(), zipToDest.getTimeZone()));
				newZipToDest.setProcessed('N');
				if (StringUtils.isBlank(zipToDest.getDestinationTerminal())) {
					newZipToDest.setTransactionType('D');
					newZipToDest.setDestinationTerminal("0");
				} else {
					newZipToDest.setTransactionType('M');
					newZipToDest.setDestinationTerminal(zipToDest.getDestinationTerminal());
				}
				newZipToDest.setCurrent('N');
				newZipToDest.setUuid(uuid.toString());
				newZipToDest.setCancelledFlag('N');
				newZipToDest.setCancelledTimestamp(null);
				newZipToDest.setCancelledUser("");
				zipToDestRepository.save(newZipToDest);
			});
		} catch (Exception exception) {
			log.error("ZDServiceImpl: prepareNewZipToDestRecords catch exception" + exception.getMessage());
			throw new ApplicationException(exception);
		}
	}

	@SuppressWarnings({ "static-access", "deprecation" })
	private Timestamp convertDateTime(Timestamp currentDateTime, String timeZone) {
		log.info("ZDServiceImpl : convertDateTime");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss a");
		int post = timeZone.trim().indexOf(')');
		String updatedTimeZone = timeZone.substring(++post).trim();
		ZoneId fromTimeZone = ZoneId.of(updatedTimeZone);
		ZoneId toTimeZone = ZoneId.of("UTC");
		ZonedDateTime currentUSATime = currentDateTime.toLocalDateTime().atZone(fromTimeZone);
		ZonedDateTime currentUTCTime = currentUSATime.withZoneSameInstant(toTimeZone);
		String df = formatter.format(currentUTCTime);
		Timestamp UTCTimestamp = new Timestamp(new Date().parse(df));
		log.info("ZDServiceImpl : given time is converted to UTC time zone");
		log.debug("ZDServiceImpl : convertDateTime, UTC timestamp {}", UTCTimestamp);
		return UTCTimestamp;
	}

	/**
	 * 
	 * @param zipToDestAddRequest user inputs
	 * @return
	 */
	private ZipToDest setZipToDestAddRequestToZipToDest(ZipToDestAddRequest zipToDestAddRequest) throws ParseException {
		log.info("ServiceImpl: set records with all valid inputs and validation");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd.HH:mm:ss");
		Date formatedDate = sdf.parse(zipToDestAddRequest.getEffectiveDate());
		Timestamp timestamp = new java.sql.Timestamp(formatedDate.getTime());

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(zipToDestAddRequest.getCountryCode());
		zipToDest.setNetwork(zipToDestAddRequest.getNetwork().trim());
		zipToDest.setCreationDate(new Timestamp(System.currentTimeMillis()));
		zipToDest.setCreationUser(zipToDestAddRequest.getCreationUser());
		zipToDest.setState(zipToDestAddRequest.getState().trim());

		String zipCode = zipToDestAddRequest.getZipCode().trim();
		if (validationUtil.isValidUsaZipCode(zipCode)) {
			zipCode = StringUtils.rightPad(zipCode, 11, '0');
		}

		zipToDest.setZipCode(zipCode);
		zipToDest.setDestinationTerminal(zipToDestAddRequest.getDestinationTerminal().trim());
		zipToDest.setEffectiveDate(convertDateTime(timestamp, zipToDestAddRequest.getTimeZone()));
		zipToDest.setTransactionType('A');
		zipToDest.setCurrent('N');
		zipToDest.setProcessed('N');
		zipToDest.setCancelledFlag('N');
		zipToDest.setCancelledTimestamp(null);
		zipToDest.setCancelledUser("");
		return zipToDest;
	}

	/**
	 * Returns a list of ZipToDestNotProcessed records.
	 */
	public List<ZipToDestNotProcessed> getNotProcessedZDRecords() {
		log.info("ZDServiceImpl : Getting Not processed ZDRecords from transaction table.");
		log.info(
				"ZDServiceImpl : Calling  getUniqueZipToDestNotProcessed method and it will return a list of ZipToDestNotProcessed records.");
		return getUniqueZipToDestNotProcessed(zipToDestRepository.findZipToDestNotProcessed());
	}

	/**
	 * Return a list of ZipToDestNotProcessed objects. The list contains a number of
	 * unique transactions. That is ZipToDest with same UUID and a range of
	 * fromZipCode and toZipCode. For Example:
	 * 
	 * ZipToDest(network,zipcode,uuid);
	 * ZipToDestNotProcessed(network,fromZipCode,toZipCode,uuid);
	 * 
	 * 1-> ZipToDest('FXG', '1230', '123') 2-> ZipToDest('FXG', '1231', '123') 3->
	 * ZipToDest('FXG', '1232', '123') 4-> ZipToDest('FXG', '1234', '123') 5->
	 * ZipToDest('FXG', '1233', '124') 6-> ZipToDest('FXG', '1235', '125')
	 * 
	 * Here the first 4 records will treated as a one transaction and 5 and 6 will
	 * be two transactions. So the method will return a list which containing 3
	 * transactions.
	 * 
	 * 1->ZipToDestNotProcessed('FXG', '1230', '1234', 123)
	 * 2->ZipToDestNotProcessed('FXG', '1233', '1233', 124)
	 * 3->ZipToDestNotProcessed('FXG', '1235', '1235', 125)
	 * 
	 * @param listZipToDestNotProcessed
	 * @return list of ZipToDestNotProcessed.
	 */
	private List<ZipToDestNotProcessed> getUniqueZipToDestNotProcessed(List<ZipToDest> listZipToDestNotProcessed) {
		log.info("ZDServiceImpl : getUniqueZipToDestNotProcessed");
		List<ZipToDestNotProcessed> output = new ArrayList<>();

		int currentIndex = 1;

		if (!listZipToDestNotProcessed.isEmpty()) {
			log.info(
					"ZDServiceImpl : getUniqueZipToDestNotProcessed - processing list of ZDRecords to create a list of distinct transactions based on it's UUID.");
			ZipToDestNotProcessed zipToDestNotProcessed = null;
			String currentUUID;
			String previousToZipCode = "";
			String previousUUID = "";
			for (ZipToDest zipToDest : listZipToDestNotProcessed) {

				currentUUID = zipToDest.getUuid();

				if (StringUtils.isEmpty(previousUUID)) {
					zipToDestNotProcessed = new ZipToDestNotProcessed(zipToDest);
				} else if ((StringUtils.compare(currentUUID, previousUUID) != 0) && zipToDestNotProcessed != null) {
					zipToDestNotProcessed.setZipTo(previousToZipCode);
					output.add(zipToDestNotProcessed);
					zipToDestNotProcessed = new ZipToDestNotProcessed(zipToDest);
				}

				if (listZipToDestNotProcessed.size() == currentIndex && zipToDestNotProcessed != null) {
					zipToDestNotProcessed.setZipTo(zipToDest.getZipCode());
					output.add(zipToDestNotProcessed);
				}

				previousUUID = currentUUID;
				previousToZipCode = zipToDest.getZipCode();

				currentIndex++;
			}
		}
		log.info(
				"ZDServiceImpl : Exiting getUniqueZipToDestNotProcessed and returning list of distinct transactions based on its UUID.");
		return output;
	}

	/**
	 * 
	 */
	public int cancelZipToDestNotProcessed(ZipToDestCancelRequest zipToDestCancelRequest) {
		log.debug("ZDServiceImpl::cancelZipToDestNotProcessed - User Name {}", zipToDestCancelRequest.getUser());
		log.debug("ZDServiceImpl::cancelZipToDestNotProcessed - {} UUID's for cancelling.",
				zipToDestCancelRequest.getUuid().size());
		int updateCount = 0;
		for (String uuid : zipToDestCancelRequest.getUuid()) {
			log.debug("ZDServiceImpl::cancelZipToDestNotProcessed - Cancelling UUID - {}", uuid);
			if (StringUtils.isNotEmpty(uuid)) {
				int counter = cancelZipToDest(zipToDestCancelRequest.getUser(),
						zipToDestRepository.findZipToDestByProcessedAndUuid(uuid));
				updateCount += counter;
				log.debug(
						"ZDServiceImpl::cancelZipToDestNotProcessed - {} Not processed transaction with UUID {} has been Cancelled.",
						counter, uuid);
			}
		}
		log.info("ZDServiceImpl::cancelZipToDestNotProcessed - Cancellation of not processed transaction completed.");
		return updateCount;
	}

	/**
	 * 
	 * @param cancelledUserName
	 * @param zipToDestList
	 */
	private int cancelZipToDest(String cancelledUserName, List<ZipToDest> zipToDestList) {
		int counter = 0;
		log.debug("ZDServiceImpl::cancelZipToDest - User Name : {} ", cancelledUserName);
		log.debug("ZDServiceImpl::cancelZipToDest - {} Not processed transaction found for the UUID ",
				zipToDestList.size());
		log.info("ZDServiceImpl::cancelZipToDest - Iterating through a list of ZipToDest records.");
		for (ZipToDest zipToDest : zipToDestList) {
			log.debug("ZDServiceImpl::cancelZipToDest - Cancelling - {} ", zipToDest);
			zipToDest.setCancelledUser(cancelledUserName);
			zipToDest.setCancelledTimestamp(validationUtil.getCurrentUTCDateTime());
			zipToDest.setCancelledFlag('Y');
			zipToDestRepository.save(zipToDest);
			counter++;
		}
		return counter;
	}

}
