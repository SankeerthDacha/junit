package com.fedex.ziptodest.server.exception;
/*
 *  Application Exception class is the Customized Exception class for user defined exceptions
 */
public class ApplicationException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private String code;

	public ApplicationException() {
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @param message
	 */

	public ApplicationException(String code, String message) {
		super(message);
		this.code = code;
	}

	/**
	 * @param exception
	 */

	public ApplicationException(Exception exception) {
		super(exception);
	}

	/**
	 * @param message
	 * @param throwable
	 */
	public ApplicationException(String message, Throwable throwable) {
		super(message, throwable);
	}

}
