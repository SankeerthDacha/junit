package com.fedex.ziptodest.server.model;

import java.sql.Timestamp;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 
 * @author 3818669
 *
 */
public class ZipToDestNotProcessed {

	@NotEmpty
	private String network;

	@NotEmpty
	private int countryCode;

	private String zipFrom;
	private String zipTo;

	@NotEmpty
	private String destinationTerminal;

	@NotEmpty
	private String creationUser;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	private Timestamp creationDate;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	private Timestamp effectiveDate;

	@NotEmpty
	private char processed;

	@NotEmpty
	private String uuid;

	public ZipToDestNotProcessed() {
		super();
	}

	public ZipToDestNotProcessed(ZipToDest zipToDest) {
		this.network = zipToDest.getNetwork();
		this.countryCode = zipToDest.getCountryCode();
		this.destinationTerminal = zipToDest.getDestinationTerminal();
		this.zipFrom = zipToDest.getZipCode();
		this.creationUser = zipToDest.getCreationUser();
		this.creationDate = zipToDest.getCreationDate();
		this.effectiveDate = zipToDest.getEffectiveDate();
		this.processed = zipToDest.getProcessed();
		this.uuid = zipToDest.getUuid();
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public int getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}

	public String getZipFrom() {
		return zipFrom;
	}

	public void setZipFrom(String zipFrom) {
		this.zipFrom = zipFrom;
	}

	public String getZipTo() {
		return zipTo;
	}

	public void setZipTo(String zipTo) {
		this.zipTo = zipTo;
	}

	public String getDestinationTerminal() {
		return destinationTerminal;
	}

	public void setDestinationTerminal(String destinationTerminal) {
		this.destinationTerminal = destinationTerminal;
	}

	public String getCreationUser() {
		return creationUser;
	}

	public void setCreationUser(String creationUser) {
		this.creationUser = creationUser;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Timestamp getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Timestamp effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public char getProcessed() {
		return processed;
	}

	public void setProcessed(char processed) {
		this.processed = processed;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((uuid == null) ? 0 : uuid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ZipToDestNotProcessed other = (ZipToDestNotProcessed) obj;
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid)) {
			return false;
		}
		return true;
	}

}
