package com.fedex.ziptodest.server.controller;

import java.text.ParseException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.ziptodest.server.model.ZipToDest;
import com.fedex.ziptodest.server.model.ZipToDestAddRequest;
import com.fedex.ziptodest.server.model.ZipToDestCancelRequest;
import com.fedex.ziptodest.server.model.ZipToDestDeleteRequest;
import com.fedex.ziptodest.server.model.ZipToDestModifyRequest;
import com.fedex.ziptodest.server.model.ZipToDestNotProcessed;
import com.fedex.ziptodest.server.model.ZipToDestStatusResponse;
import com.fedex.ziptodest.server.service.ZDService;
import com.fedex.ziptodest.server.utils.ValidationUtil;
import com.fedex.ziptodest.server.utils.ZipToDestConstants;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(value = "/current/record")
public class ZipToDestController {

	@Autowired
	private ZDService zDService;

	@Autowired
	private ValidationUtil validationUtil;

	public static final Logger log = LoggerFactory.getLogger(ZipToDestController.class);

	/**
	 * Get all records from Tans_zip_to_dest table.
	 * 
	 * @return List of records.
	 */
	@GetMapping(value = "/get", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ZipToDest>> getAllZDRecord() {
		log.info("Request: get");
		return ResponseEntity.ok(zDService.getAllZDRecord());
	}

	/**
	 * Add the records as given as input
	 * 
	 * @param addZipToDestRequest
	 * @return Status success if the records get added.
	 * @throws ParseException
	 */
	@PostMapping(value = "/add", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<ZipToDestStatusResponse> addZDRecord(@RequestBody ZipToDestAddRequest addZipToDestRequest)
			throws ParseException {
		log.info("Request: add");
		ResponseEntity<ZipToDestStatusResponse> response;
		String validationResponse = validationUtil.validateAddRequest(addZipToDestRequest);

		if (!ZipToDestConstants.VALID.equals(validationResponse)) {
			response = getZipToDestStatusResponse(ZipToDestConstants.INVALID, validationResponse,
					HttpStatus.BAD_REQUEST);
		} else {
			zDService.addZDRecord(addZipToDestRequest);
			log.info("Records added successfully to Transaction table, exit controller");
			response = getZipToDestStatusResponse(ZipToDestConstants.RESPONSE_SUCCESS_MSG,
					ZipToDestConstants.RESPONSE_ADD_MSG, HttpStatus.OK);
		}

		return response;

	}

	/**
	 * Insert new records with the updated destination and effective date which
	 * falls between the given zipcode ranges.
	 * 
	 * @param zipToDestModifyRequest
	 *            Accept the input request
	 * @return if records gets modified then success message else return
	 *         exception message.
	 * @throws ParseException
	 * 
	 */
	@PutMapping(value = "/modify", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<ZipToDestStatusResponse> modifyZDRecord(
			@RequestBody ZipToDestModifyRequest zipToDestModifyRequest) throws ParseException {
		ResponseEntity<ZipToDestStatusResponse> zipToDestStatusResponse = null;
		log.info("ZipToDestController : Entering modifyZDRecord");

		String validationResponse = validationUtil.validateModifyRequest(zipToDestModifyRequest);

		if (!ZipToDestConstants.VALID.equals(validationResponse)) {
			zipToDestStatusResponse = getZipToDestStatusResponse(ZipToDestConstants.INVALID, validationResponse,
					HttpStatus.BAD_REQUEST);
		} else {
			String response = zDService.modifyRecords(zipToDestModifyRequest);

			if (null != response && response.equals(ZipToDestConstants.RESPONSE_SUCCESS_MSG)) {
				log.info("ZipToDestController : Exiting modifyZDRecord");
				zipToDestStatusResponse = getZipToDestStatusResponse(ZipToDestConstants.RESPONSE_SUCCESS_MSG,
						ZipToDestConstants.RESPONSE_MODIFY_MSG, HttpStatus.OK);
			} else {
				log.debug(" ZipToDestController modify {} ", response);
				zipToDestStatusResponse = getZipToDestStatusResponse(ZipToDestConstants.RESPONSE_ERROR_MSG, response,
						HttpStatus.BAD_REQUEST);
			}
		}
		return zipToDestStatusResponse;
	}

	/**
	 * Insert the new records to the transaction table without destination and
	 * with new effective date.
	 * 
	 * @param zipToDestDeleteRequest
	 *            accept the input request
	 * @return if records gets deleted then success message else return
	 *         exception message.
	 * @throws ParseException
	 */
	@DeleteMapping(value = "/delete", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<ZipToDestStatusResponse> deleteZDRecord(
			@RequestBody ZipToDestDeleteRequest zipToDestDeleteRequest) throws ParseException {
		ResponseEntity<ZipToDestStatusResponse> zipToDestStatusResponse = null;
		log.info("Request: delete");
		String validationResponse = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);

		if (!ZipToDestConstants.VALID.equals(validationResponse)) {
			zipToDestStatusResponse = getZipToDestStatusResponse(ZipToDestConstants.INVALID, validationResponse,
					HttpStatus.BAD_REQUEST);
		} else {
			String response = zDService.deleteRecords(zipToDestDeleteRequest);
			if (null != response && response.equals(ZipToDestConstants.RESPONSE_SUCCESS_MSG)) {
				log.info("Records deleteZDRecord updated, exit controller");
				zipToDestStatusResponse = getZipToDestStatusResponse(ZipToDestConstants.RESPONSE_SUCCESS_MSG,
						ZipToDestConstants.RESPONSE_DELETE_MSG, HttpStatus.OK);
			} else {
				log.debug(" ZipToDestController delete {} ", response);
				zipToDestStatusResponse = getZipToDestStatusResponse(ZipToDestConstants.RESPONSE_ERROR_MSG, response,
						HttpStatus.BAD_REQUEST);
			}
		}
		return zipToDestStatusResponse;
	}

	/**
	 * Returns a list of ZipToDestNotProcessed object which are not processed.
	 * 
	 * @return List of ZipToDestNotProcessed records.
	 */
	@GetMapping(value = "/futureTransactions/get", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ZipToDestNotProcessed>> getNotProcessedZDRecord() {
		log.info("Request: futureTransactions/get");
		return new ResponseEntity<>(zDService.getNotProcessedZDRecords(), HttpStatus.OK);
	}

	/**
	 * Method will process list of ZipToDestNotProcessed records and updates its
	 * corresponding ZipToDest record as cancelled in the transaction table.
	 * 
	 * @param zipToDestCancelRequest
	 * @return
	 */
	@PutMapping(value = "/futureTransactions/cancel", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<ZipToDestStatusResponse> cancelNotProcessedZDRecord(
			@RequestBody ZipToDestCancelRequest zipToDestCancelRequest) {
		log.info("::cancelNotProcessedZDRecord - Cancelling future transactions.");
		log.debug("::cancelNotProcessedZDRecord - User Input - {}.", zipToDestCancelRequest);
		ResponseEntity<ZipToDestStatusResponse> response = null;

		String validationResponse = validationUtil.validateCancelRequest(zipToDestCancelRequest);

		if (ZipToDestConstants.VALID.equals(validationResponse)) {
			log.debug("::cancelNotProcessedZDRecord - User Name : {}", zipToDestCancelRequest.getUser());
			log.debug("::cancelNotProcessedZDRecord - Count of UUID's : {}", zipToDestCancelRequest.getUuid().size());

			try {
				int updateCount = zDService.cancelZipToDestNotProcessed(zipToDestCancelRequest);
				if (updateCount == 0) {
					response = getZipToDestStatusResponse(ZipToDestConstants.RESPONSE_SUCCESS_MSG,
							ZipToDestConstants.RESPONSE_CANCEL_SUCCESS_MSG, HttpStatus.NO_CONTENT);
				} else {
					response = getZipToDestStatusResponse(ZipToDestConstants.RESPONSE_SUCCESS_MSG,
							ZipToDestConstants.RESPONSE_CANCEL_SUCCESS_MSG, HttpStatus.OK);
				}
				log.debug("::cancelNotProcessedZDRecord - Selected not processed records are successfully cancelled.");
			} catch (Exception exception) {
				log.debug("::cancelNotProcessedZDRecord - Exception occured : {}", exception.getMessage());
				response = getZipToDestStatusResponse(ZipToDestConstants.RESPONSE_ERROR_MSG,
						ZipToDestConstants.RESPONSE_CANCEL_ERROR_MSG, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			log.debug("::cancelNotProcessedZDRecord - The payload missing user name or list of uuid.");
			response = getZipToDestStatusResponse(ZipToDestConstants.INVALID, validationResponse,
					HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	private ResponseEntity<ZipToDestStatusResponse> getZipToDestStatusResponse(String statusCode, String message,
			HttpStatus httpStatus) {
		return new ResponseEntity<>(new ZipToDestStatusResponse(statusCode, message), httpStatus);
	}

}
