package com.fedex.ziptodest.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.ComponentScan;

@ServletComponentScan
@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.fedex.*" })
public class ZDServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZDServerApplication.class, args);
		System.out.println("Server Started");
	}
}
