package com.fedex.ziptodest.server.service;

import java.text.ParseException;
import java.util.List;

import com.fedex.ziptodest.server.model.ZipToDest;
import com.fedex.ziptodest.server.model.ZipToDestAddRequest;
import com.fedex.ziptodest.server.model.ZipToDestCancelRequest;
import com.fedex.ziptodest.server.model.ZipToDestDeleteRequest;
import com.fedex.ziptodest.server.model.ZipToDestModifyRequest;
import com.fedex.ziptodest.server.model.ZipToDestNotProcessed;

public interface ZDService {

	/**
	 * 
	 * @return all records in sorted order based on zipcode
	 */
	public List<ZipToDest> getAllZDRecord();

	/**
	 * 
	 * @param zipToDestAddRequest
	 *            User input
	 * @return
	 * @throws ParseException 
	 */
	public ZipToDest addZDRecord(ZipToDestAddRequest zipToDestAddRequest) throws ParseException;

	
	public String modifyRecords(ZipToDestModifyRequest zipToDestModifyRequest) throws ParseException;
	
	public String deleteRecords(ZipToDestDeleteRequest zipToDestDeleteRequest) throws ParseException;
	
	/**
	 * @param zipToDest
	 * @return
	 */
//	public String modifyZDRecord(ZipToDest zipToDest);
	
	/**
	 * Returns a list of ZipToDest records that are not yet processed.
	 * That is, in the transaction table the records with 'Processed Flag' equals 'N'.
	 * 
	 * @return All ZipToDest records that are not processed.
	 */
	public List<ZipToDestNotProcessed> getNotProcessedZDRecords();
	
	/**
	 * 
	 * @param zipToDestNotProcessedList
	 * @return
	 */
	public int cancelZipToDestNotProcessed(ZipToDestCancelRequest zipToDestCancelRequest);

}
