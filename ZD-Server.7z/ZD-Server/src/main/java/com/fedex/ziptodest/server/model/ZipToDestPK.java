package com.fedex.ziptodest.server.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class ZipToDestPK implements Serializable {

	private static final long serialVersionUID = 1L;

	protected String network;

	protected int countryCode;

	protected String zipCode;

	protected Timestamp creationDate;

	public ZipToDestPK() {

	}

	public ZipToDestPK(String network, int countryCode, String zipCode, Timestamp creationDate) {
		super();
		this.network = network;
		this.countryCode = countryCode;
		this.zipCode = zipCode;
		this.creationDate = creationDate;
	}

	public String getNetwork() {
		return network;
	}

	public int getCountryCode() {
		return countryCode;
	}

	public String getZipCode() {
		return zipCode;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

}
