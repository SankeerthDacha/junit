package com.fedex.ziptodest.server.utils;

import java.util.regex.Pattern;

public class ZipToDestConstants {

	private ZipToDestConstants() {
		throw new AssertionError("No com.fedex.ziptodest.server.utils.ZipToDestConstants instances for you!");
	}

	public static final String SORTATION = "sortation";
	public static final String VISION_MANAGEMENT_ROLE = "vision management";
	public static final String DEFAULT_USER_ROLE = "default";

	public static final String PROP_ACTIVE_PROFILE = "active_profile";
	public static final String PROP_SORTATION_ROLE = "sortation_role";
	public static final String PROP_SVM_ROLE = "svm_role";
	public static final String PROP_JDBC_URL = "jdbc_url";
	public static final String PROP_DRIVER_CLASS = "jdbc_driver_class";
	public static final String PROP_JDBC_USER = "jdbc_username";
	public static final String PROP_JDBC_PD = "jdbc_password";
	public static final String PROP_CONTEXT_PATH = "context_path";
	public static final String PROP_SERVER_PORT = "server_port";
	public static final String PROP_SESSION_TIMEOUT = "session_timeout";
	public static final String PROP_LOG_LEVEL_FEDEX = "log_level_fedex";
	public static final String PROP_LOG_LEVEL_SPRING = "log_level_spring";
	public static final String PROP_LPI_BASE_URL = "base_url";
	public static final String PROP_LDAP_WS_URL = "ldap_ws_url";

	public static final String RESPONSE_SUCCESS_MSG = "success";
	public static final String RESPONSE_ERROR_MSG = "error";
	public static final int RESPONSE_CD_SUCCESS = 200;

	public static final String RESPONSE_MODIFY_MSG = "The requested record has been updated successfully.";
	public static final String RESPONSE_ADD_MSG = "The requested record has been added successfully.";
	public static final String RESPONSE_DELETE_MSG = "The requested record has been deleted successfully.";

	public static final String VALID = "Valid";
	public static final String INVALID = "Invalid";
	public static final String INVALID_NETWORK = "Invalid Network Type/Network type is empty";
	public static final String INVALID_DESTINATION = "Invalid Destination Code";
	public static final String INVALID_DATE = "Effective Date should be future date";
	public static final String INVALID_DATE_FUTURE = "Invalid Future Date";
	public static final String INVALID_ZIP_RANGE = "Invalid Zip Code Range";
	public static final String EMPTY_STRING = "";
	public static final String FATAL_ERROR = "Some unexpected error occured. Please try later.";
	public static final String RECORDS_NOT_PROCESSED = "Records are not processed/No zipcode falls between given range";

	public static final String UNPROCESSED_TRANSACTIONS = "There are already unprocessed transactions for one or more zipcodes in the given range";
	public static final String UNPROCESSED_EFFECTIVE_DATE = "The effective date should be a future date to the existing modification request";

	public static final String RESPONSE_CANCEL_SUCCESS_MSG = "The not processed transactions are cancelled successfully.";
	public static final String RESPONSE_CANCEL_ERROR_MSG = "Not processed transaction(s) cancellation failed.";
	public static final String INVALID_CANCEL_USER = "The user name is required.";
	public static final String INVALID_EMPTY_UUID_LIST = "The UUID list is required.";
	public static final String INVALID_UUID_LIST = "Invalid UUID list - The UUID list contains empty value(s).";
	public static final String RESPONSE_INVALID_REQUEST_MSG = "Invalid Request.";

	public static final String ZIPCODE_EXISTS = "The zipcode %s pre-exists for the network %s.";
	public static final String INVALID_ZIPCODE = "Invalid Zip code/Zip code is empty.";
	public static final String DESTINATION_NOT_EXISTS = "The destination code %s is not a valid one.";
	public static final String EFFECTIVE_DATE_FORMAT = "yyyy-MM-dd.HH:mm:ss";

	// US Zipcode Pattern
	public static final Pattern PATTERN_US_ZIP_CODE = Pattern.compile("[0-9]{5,5}");

}
