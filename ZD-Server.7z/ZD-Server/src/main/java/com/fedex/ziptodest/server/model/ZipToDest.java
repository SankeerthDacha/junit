package com.fedex.ziptodest.server.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "TRX_ZIP_TO_DEST")
@IdClass(ZipToDestPK.class)

public class ZipToDest {

	@Id
	@NotNull
	@Column(name = "NETWORK")
	private String network;

	@Id
	@NotNull
	@Column(name = "COUNTRY_CD")
	private int countryCode;

	@Id
	@NotNull
	@Column(name = "ZIP_CD")
	private String zipCode;

	@Id
	@NotNull
	@Column(name = "CREATION_DATE_TMSTP")
	private Timestamp creationDate;

	@NotNull
	@Column(name = "STATE")
	private String state;

	@NotNull
	@Column(name = "DEST_TERMINAL")
	private String destinationTerminal;

	@NotNull
	@Column(name = "CREATION_USER")
	private String creationUser;

	@NotNull
	@Column(name = "EFFECTIVE_DATE_TMSTP")
	@JsonFormat( pattern = "yyyy-MM-dd.HH:mm:ss")
	private Timestamp effectiveDate;

	@NotNull
	@Column(name = "TRANS_TYPE")
	private char transactionType;

	@NotNull
	@Column(name = "PROCESSED_FLG")
	private char processed;

	@NotNull
	@Column(name = "CURRENT_FLG")
	private char current;

	@Column(name = "UUID")
	private String uuid;

	@Column(name = "CANCELLED_USER")
	private String cancelledUser;

	@Column(name = "CANCELLED_DATE_TMSTP")
	private Timestamp cancelledTimestamp;

	@Column(name = "CANCELLED_FLG")
	private char cancelledFlag;

	@Transient
	@JsonInclude(Include.NON_DEFAULT)
	private String zipFrom;

	@Transient
	@JsonInclude(Include.NON_DEFAULT)
	private String zipTo;
	
	@Transient
	@JsonInclude(Include.NON_DEFAULT)
	private String timeZone;

	
	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getZipFrom() {
		return zipFrom;
	}

	public void setZipFrom(String zipFrom) {
		this.zipFrom = zipFrom;
	}

	public String getZipTo() {
		return zipTo;
	}

	public void setZipTo(String zipTo) {
		this.zipTo = zipTo;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public int getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(int country) {
		this.countryCode = country;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDestinationTerminal() {
		return destinationTerminal;
	}

	public void setDestinationTerminal(String destinationTerminal) {
		this.destinationTerminal = destinationTerminal;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreationUser() {
		return creationUser;
	}

	public void setCreationUser(String creationUser) {
		this.creationUser = creationUser;
	}

	public Timestamp getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Timestamp effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public char getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(char transactionType) {
		this.transactionType = transactionType;
	}

	public char getProcessed() {
		return processed;
	}

	public void setProcessed(char processed) {
		this.processed = processed;
	}

	public char getCurrent() {
		return current;
	}

	public void setCurrent(char current) {
		this.current = current;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCancelledUser() {
		return cancelledUser;
	}

	public void setCancelledUser(String cancelledUser) {
		this.cancelledUser = cancelledUser;
	}

	public Timestamp getCancelledTimestamp() {
		return cancelledTimestamp;
	}

	public void setCancelledTimestamp(Timestamp cancelledTimestamp) {
		this.cancelledTimestamp = cancelledTimestamp;
	}

	public char getCancelledFlag() {
		return cancelledFlag;
	}

	public void setCancelledFlag(char cancelledFlag) {
		this.cancelledFlag = cancelledFlag;
	}

	@Override
	public String toString() {
		return "ZipToDest [network=" + network + ", countryCode=" + countryCode + ", zipCode=" + zipCode
				+ ", creationDate=" + creationDate + ", state=" + state + ", destinationTerminal=" + destinationTerminal
				+ ", creationUser=" + creationUser + ", effectiveDate=" + effectiveDate + ", transactionType="
				+ transactionType + ", processed=" + processed + ", current=" + current + ", uuid=" + uuid
				+ ", cancelledUser=" + cancelledUser + ", cancelledTimestamp=" + cancelledTimestamp + ", cancelledFlag="
				+ cancelledFlag + ", zipFrom=" + zipFrom + ", zipTo=" + zipTo + ", timeZone=" + timeZone + "]";
	}
	
	

}
