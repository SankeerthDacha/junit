package com.fedex.ziptodest.server.utils;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

//import com.fedex.ziptodest.iseries.service.DestinationService;
import com.fedex.ziptodest.server.model.ZipToDest;
import com.fedex.ziptodest.server.model.ZipToDestAddRequest;
import com.fedex.ziptodest.server.model.ZipToDestCancelRequest;
import com.fedex.ziptodest.server.model.ZipToDestDeleteRequest;
import com.fedex.ziptodest.server.model.ZipToDestModifyRequest;
import com.fedex.ziptodest.server.repository.ZipToDestRepository;

/**
 * @author 3790999
 *
 */
@Component
public class ValidationUtil {

	public static final Logger LOGGER = LoggerFactory.getLogger(ValidationUtil.class);
	private final SimpleDateFormat effectiveDateFormat = new SimpleDateFormat(ZipToDestConstants.EFFECTIVE_DATE_FORMAT);

	@Autowired
	private ZipToDestRepository zipToDestRepository;

	/*
	 * @Autowired private DestinationService destinationService;
	 */

	public String validateAddRequest(ZipToDestAddRequest zipToDestAddRequest) {
		String output = ZipToDestConstants.VALID;
		try {
			if (StringUtils.isBlank(zipToDestAddRequest.getNetwork())) {
				LOGGER.debug("Blank Network code supplied : {}. ", zipToDestAddRequest.getNetwork());
				output = ZipToDestConstants.INVALID_NETWORK;
			} else if (StringUtils.isBlank(zipToDestAddRequest.getZipCode())) {
				LOGGER.debug("Blank Zipcode supplied : {}. ", zipToDestAddRequest.getZipCode());
				output = ZipToDestConstants.INVALID_ZIPCODE;
			} else if (isZipCodeExists(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode())) {
				LOGGER.debug("Zipcode {} not found with network code {}. ", zipToDestAddRequest.getZipCode(),
						zipToDestAddRequest.getNetwork());
				output = String.format(ZipToDestConstants.ZIPCODE_EXISTS, zipToDestAddRequest.getZipCode(),
						zipToDestAddRequest.getNetwork());
			} else if (!isValidDestination(zipToDestAddRequest.getDestinationTerminal())) {
				LOGGER.debug("Invalid destination supplied : {} ", zipToDestAddRequest.getDestinationTerminal());
				output = ZipToDestConstants.INVALID_DESTINATION;
			} /*
				 * else if (!destinationService.isDestinationExist(zipToDestAddRequest.
				 * getDestinationTerminal())) { LOGGER.
				 * debug("Invalid destination supplied. The given terminal number not found in iSeries 508 table."
				 * ); output = String.format(ZipToDestConstants.DESTINATION_NOT_EXISTS,
				 * zipToDestAddRequest.getDestinationTerminal()); }
				 */ else if (StringUtils.isNotBlank(zipToDestAddRequest.getEffectiveDate())) {
				Timestamp effectiveTimestamp = fromStringToTimestamp(instanceOfEffectiveDateFormat(),
						zipToDestAddRequest.getEffectiveDate());
				LOGGER.debug("Effective Timestamp : {}", effectiveTimestamp);

				if (null != effectiveTimestamp) {
					Timestamp effectiveUtcTimestamp = fromTimestampToUtcTimestamp(effectiveTimestamp,
							zipToDestAddRequest.getTimeZone());
					LOGGER.debug("Effective Timestamp in UTC Zone : {}", effectiveUtcTimestamp);

					if (!isFutureDate(effectiveUtcTimestamp, getCurrentUTCDateTime())) {
						output = ZipToDestConstants.INVALID_DATE;
					}
				} else {
					output = ZipToDestConstants.INVALID_DATE_FUTURE;
				}
			} else {
				output = ZipToDestConstants.INVALID_DATE_FUTURE;
			}

		} catch (Exception exp) {
			LOGGER.debug("Excpetion occured during add validation : {}", exp);
			output = ZipToDestConstants.FATAL_ERROR;
		}

		return output;
	}

	/**
	 * @param zipToDestRequest
	 * @return
	 */
	public String validateModifyRequest(ZipToDestModifyRequest modifyRequest) {
		LOGGER.info("ValidationUtil : Entering validateModifyInput");
		String output = ZipToDestConstants.VALID;

		String network = modifyRequest.getNetwork();
		String zipFrom = modifyRequest.getZipFrom();
		String zipTo = modifyRequest.getZipTo();
		String effectiveDate = modifyRequest.getEffectiveDate();
		String timezone = modifyRequest.getTimeZone();
		Timestamp effectiveTimestamp = fromStringToTimestamp(instanceOfEffectiveDateFormat(),
				modifyRequest.getEffectiveDate());

		if (!isEffectiveDateValid(effectiveTimestamp)) {
			output = ZipToDestConstants.INVALID_DATE;
		} else if (StringUtils.isBlank(network)) {
			output = ZipToDestConstants.INVALID_NETWORK;
		} else if (!isValidDestination(modifyRequest.getDestinationTerminal())) {
			output = ZipToDestConstants.INVALID_DESTINATION;
		} else if (StringUtils.isAnyBlank(zipFrom, zipTo)) {
			output = ZipToDestConstants.INVALID_ZIP_RANGE;
		} else if (!isZipcodeRangeExists(zipFrom, zipTo, network)) {
			LOGGER.debug("ValidationUtil::validateModifyRequest - ZipFrom : {} ", zipFrom);
			LOGGER.debug("ValidationUtil::validateModifyRequest - ZipTo : {} ", zipTo);
			output = ZipToDestConstants.RECORDS_NOT_PROCESSED;
		} else {
			output = modifyRequestProcess(zipFrom, zipTo, network, effectiveDate, timezone);
		}

		LOGGER.debug("Validatemodifyinput : {}", output);
		return output;
	}

	/**
	 * @param zipToDestDeleteRequest
	 * @return
	 */
	public String validateDeleteRequest(ZipToDestDeleteRequest zipToDestDeleteRequest) {

		String output = ZipToDestConstants.VALID;

		String network = zipToDestDeleteRequest.getNetwork();
		String zipFrom = zipToDestDeleteRequest.getZipFrom();
		String zipTo = zipToDestDeleteRequest.getZipTo();
		if (StringUtils.isBlank(zipToDestDeleteRequest.getNetwork())) {
			LOGGER.debug("ValidationUtil::validateDeleteRequest - Network : {} ", zipToDestDeleteRequest.getNetwork());
			output = ZipToDestConstants.INVALID_NETWORK;

		} else if (StringUtils.isBlank(zipToDestDeleteRequest.getEffectiveDate())) {
			output = ZipToDestConstants.INVALID_DATE_FUTURE;
		} else if (!isZipcodeRangeExists(zipFrom, zipTo, network)) {
			LOGGER.debug("ValidationUtil::validateDeleteRequest - ZipFrom : {} ", zipFrom);
			LOGGER.debug("ValidationUtil::validateDeleteRequest - ZipTo : {} ", zipTo);
			output = ZipToDestConstants.RECORDS_NOT_PROCESSED;

		} else if (isZipcodeRangeUnprocessed(zipFrom, zipTo, network)) {
			LOGGER.debug("ValidationUtil::validateDeleteRequest - ZipFrom : {} ", zipFrom);
			LOGGER.debug("ValidationUtil::validateDeleteRequest - ZipTo : {} ", zipTo);
			output = ZipToDestConstants.UNPROCESSED_TRANSACTIONS;

		} else if (StringUtils.isNotBlank(zipToDestDeleteRequest.getEffectiveDate())) {
			LOGGER.debug("ValidationUtil::validateDeleteRequest - Effective Date : {} ",
					zipToDestDeleteRequest.getEffectiveDate());

			Timestamp effectiveTimestamp = fromStringToTimestamp(instanceOfEffectiveDateFormat(),
					zipToDestDeleteRequest.getEffectiveDate());

			if (null != effectiveTimestamp) {
				Timestamp effectiveUtcTimestamp = fromTimestampToUtcTimestamp(effectiveTimestamp,
						zipToDestDeleteRequest.getTimeZone());

				output = (isFutureDate(effectiveUtcTimestamp, getCurrentUTCDateTime()) ? ZipToDestConstants.VALID
						: ZipToDestConstants.INVALID_DATE_FUTURE);
			} else {
				output = ZipToDestConstants.INVALID_DATE_FUTURE;
			}
		}

		return output;
	}

	public String validateCancelRequest(ZipToDestCancelRequest zipToDestCancelRequest) {
		String output = ZipToDestConstants.VALID;
		if (zipToDestCancelRequest != null) {
			if (StringUtils.isBlank(zipToDestCancelRequest.getUser())) {
				output = ZipToDestConstants.INVALID_CANCEL_USER;
			} else if (zipToDestCancelRequest.getUuid() != null) {
				if (zipToDestCancelRequest.getUuid().isEmpty()) {
					output = ZipToDestConstants.INVALID_EMPTY_UUID_LIST;
				} else {
					output = zipToDestCancelRequest.getUuid().stream().anyMatch(StringUtils::isBlank)
							? ZipToDestConstants.INVALID_UUID_LIST
							: ZipToDestConstants.VALID;
				}
			} else {
				output = ZipToDestConstants.INVALID_EMPTY_UUID_LIST;
			}
		} else {
			output = ZipToDestConstants.INVALID;
		}
		return output;
	}

	public boolean isValidDestination(String destination) {
		boolean output = false;
		if (StringUtils.isNotBlank(destination) && StringUtils.isNumeric(destination)) {
			int dest = Integer.parseInt(destination);
			output = (dest >= 1 && dest <= 9999);
		}
		return output;
	}

	public SimpleDateFormat instanceOfEffectiveDateFormat() {
		return effectiveDateFormat;
	}

	/**
	 * @param dateToValidate
	 * @param dateFormat
	 * @return
	 */
	public boolean isEffectiveDateValid(Timestamp dateToValidate) {
		boolean output = false;
		LOGGER.info("ValidationUtil : Entering isThisDateValid");
		if (dateToValidate != null) {
			LocalDateTime date = dateToValidate.toLocalDateTime();
			LOGGER.info("ValidationUtil : Exiting isThisDateValid");
			output = date.isAfter(LocalDateTime.now());
		}
		return output;
	}

	public String isDateFormatValid(String effectiveDate) {
		String output = ZipToDestConstants.INVALID;
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ZipToDestConstants.EFFECTIVE_DATE_FORMAT,
					Locale.ENGLISH);
			LocalDateTime.parse(effectiveDate, formatter);
			output = ZipToDestConstants.VALID;
		} catch (Exception e) {
			output = ZipToDestConstants.INVALID;
		}
		return output;
	}

	public Timestamp convertDateToTimeStamp(String effectiveDate) throws ParseException {
		Date formatedDate = effectiveDateFormat.parse(effectiveDate);
		return new java.sql.Timestamp(formatedDate.getTime());
	}

	public boolean isValidUsaZipCode(String zipCode) {
		return (ZipToDestConstants.PATTERN_US_ZIP_CODE.matcher(zipCode).matches());
	}

	public Timestamp getCurrentUTCDateTime() {
		ZonedDateTime zonedDateTime = Instant.now().atZone(ZoneOffset.UTC);
		return Timestamp.valueOf(zonedDateTime.toLocalDateTime());
	}

	public boolean isZipCodeExists(String network, String zipCode) {
		boolean output = false;
		if (StringUtils.isNotBlank(network) && StringUtils.isNotBlank(zipCode)) {
			LOGGER.debug("::isZipCodeExists - Network Code : {}", network);
			LOGGER.debug("::isZipCodeExists - ZipCode : {}", zipCode);
			ZipToDest processedZipToDest = zipToDestRepository.findExistingProcessedZipcode(network,
					isValidUsaZipCode(zipCode) ? StringUtils.rightPad(zipCode, 11, '0') : zipCode);
			ZipToDest unprocessedZipToDest = zipToDestRepository.findExistingUnprocessedZipcode(network,
					isValidUsaZipCode(zipCode) ? StringUtils.rightPad(zipCode, 11, '0') : zipCode);
			if (null != processedZipToDest || null != unprocessedZipToDest)
				output = true;
		}
		return output;
	}

	private Timestamp fromTimestampToUtcTimestamp(Timestamp currentDateTime, String timeZone) {
		int post = timeZone.trim().indexOf(')');
		String updatedTimeZone = timeZone.substring(++post).trim();
		ZoneId fromTimeZone = ZoneId.of(updatedTimeZone);
		ZoneId toTimeZone = ZoneId.of("UTC");
		ZonedDateTime currentUSATime = currentDateTime.toLocalDateTime().atZone(fromTimeZone);
		ZonedDateTime currentUTCTime = currentUSATime.withZoneSameInstant(toTimeZone);
		return Timestamp.valueOf(currentUTCTime.toLocalDateTime());
	}

	private Timestamp fromStringToTimestamp(SimpleDateFormat simpleDateFormat, String strDate) {
		Timestamp timestamp = null;
		try {
			Date formatedDate = simpleDateFormat.parse(strDate);
			timestamp = new Timestamp(formatedDate.getTime());
		} catch (Exception exception) {
			LOGGER.debug(exception.getMessage());
		}
		return timestamp;
	}

	private boolean isFutureDate(Timestamp effecticeTimestamp, Timestamp currentTimestamp) {
		return (effecticeTimestamp.compareTo(currentTimestamp) > 0);
	}

	private boolean isZipcodeRangeExists(String zipFrom, String zipTo, String network) {
		List<ZipToDest> processedRecords;

		if (StringUtils.isNotBlank(network) && StringUtils.isNotBlank(zipFrom) && StringUtils.isNotBlank(zipTo)) {
			zipFrom = isValidUsaZipCode(zipFrom) ? StringUtils.rightPad(zipFrom, 11, '0') : zipFrom;
			zipTo = isValidUsaZipCode(zipTo) ? StringUtils.rightPad(zipTo, 11, '0') : zipTo;
			processedRecords = zipToDestRepository.findProcessedZipcodeBetweenTwoRange(zipFrom, zipTo, network);
			return processedRecords.isEmpty() ? false : true;
		}
		return false;
	}

	private boolean isZipcodeRangeUnprocessed(String zipFrom, String zipTo, String network) {
		List<ZipToDest> unprocessedDeleteTransactions, unprocessedModifyTransactions;

		if (StringUtils.isNotBlank(network) && StringUtils.isNotBlank(zipFrom) && StringUtils.isNotBlank(zipTo)) {
			zipFrom = isValidUsaZipCode(zipFrom) ? StringUtils.rightPad(zipFrom, 11, '0') : zipFrom;
			zipTo = isValidUsaZipCode(zipTo) ? StringUtils.rightPad(zipTo, 11, '0') : zipTo;
			unprocessedDeleteTransactions = zipToDestRepository.findUnprocessedDeleteTransactions(zipFrom, zipTo,
					network);
			unprocessedModifyTransactions = zipToDestRepository.findUnprocessedModifyTransactions(zipFrom, zipTo,
					network);
			return (CollectionUtils.isEmpty(unprocessedDeleteTransactions)
					&& CollectionUtils.isEmpty(unprocessedModifyTransactions)) ? false : true;
		}
		return false;
	}

	private String modifyRequestProcess(String zipFrom, String zipTo, String network, String effectiveDate,
			String timezone) {
		List<ZipToDest> unprocessedDeleteTransactions, unprocessedModifyTransactions;
		String output = ZipToDestConstants.VALID;
		if (StringUtils.isNotBlank(network) && StringUtils.isNotBlank(zipFrom) && StringUtils.isNotBlank(zipTo)) {
			zipFrom = isValidUsaZipCode(zipFrom) ? StringUtils.rightPad(zipFrom, 11, '0') : zipFrom;
			zipTo = isValidUsaZipCode(zipTo) ? StringUtils.rightPad(zipTo, 11, '0') : zipTo;
			unprocessedDeleteTransactions = zipToDestRepository.findUnprocessedDeleteTransactions(zipFrom, zipTo,
					network);
			unprocessedModifyTransactions = zipToDestRepository.findUnprocessedModifyTransactions(zipFrom, zipTo,
					network);

			if (CollectionUtils.isNotEmpty(unprocessedModifyTransactions)
					&& unprocessedModifyTransactions.size() == 1) {
				Timestamp effectiveTimestamp = fromStringToTimestamp(instanceOfEffectiveDateFormat(), effectiveDate);

				if (null != effectiveTimestamp) {
					Timestamp effectiveUtcTimestamp = fromTimestampToUtcTimestamp(effectiveTimestamp, timezone);

					Timestamp effectiveModifyUtcTimestamp = unprocessedModifyTransactions.get(0).getEffectiveDate();
					if (!isFutureDate(effectiveUtcTimestamp, effectiveModifyUtcTimestamp)) {
						output = ZipToDestConstants.UNPROCESSED_EFFECTIVE_DATE;
					}
				} else {
					output = ZipToDestConstants.INVALID_DATE_FUTURE;
				}
			} else if (CollectionUtils.isNotEmpty(unprocessedDeleteTransactions)
					|| (CollectionUtils.isNotEmpty(unprocessedModifyTransactions)
							&& unprocessedModifyTransactions.size() == 2)) {
				output = ZipToDestConstants.UNPROCESSED_TRANSACTIONS;
			}
		}
		return output;
	}
}
