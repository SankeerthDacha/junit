package com.fedex.ziptodest.server.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.fedex.ziptodest.server.model.ZipToDest;

public interface ZipToDestRepository extends PagingAndSortingRepository<ZipToDest, Long> {

	List<ZipToDest> findAll(Sort page);

	@Query("select d from ZipToDest  d where d.network = ?3 and  d.zipCode BETWEEN ?1 AND ?2 and d.current='Y' and d.processed='Y' ")
	List<ZipToDest> findProcessedZipcodeBetweenTwoRange(String zipCodefrom, String zipCodeTo, String network);
	
	@Query("select d from ZipToDest  d where d.network = ?3 and  d.zipCode BETWEEN ?1 AND ?2 and d.current='N' and d.processed='N' and cancelledFlag='N' and d.transactionType='D' ")
	List<ZipToDest> findUnprocessedDeleteTransactions(String zipCodeFrom, String zipCodeTo, String network);
	
	@Query("select d from ZipToDest  d where d.network = ?3 and  d.zipCode BETWEEN ?1 AND ?2 and d.current='N' and d.processed='N' and cancelledFlag='N' and d.transactionType='M' ")
	List<ZipToDest> findUnprocessedModifyTransactions(String zipCodeFrom, String zipCodeTo, String network);
	
	@Query("select d from ZipToDest  d where d.processed = 'N' and d.cancelledFlag <> 'Y' and d.uuid is not null order by d.uuid, d.zipCode asc ")
	List<ZipToDest> findZipToDestNotProcessed();
	
	@Query("select d from ZipToDest  d where d.processed = 'N' and d.cancelledFlag <> 'Y' and d.uuid = ?1 order by d.uuid, d.zipCode asc ")
	List<ZipToDest> findZipToDestByProcessedAndUuid(String uuid);
	
	@Query("select d from ZipToDest  d where d.network = ?1 and  d.zipCode = ?2 and d.transactionType='A' and d.processed='Y' ")
	ZipToDest findExistingProcessedZipcode(String network, String zipCode);
	
	@Query("select d from ZipToDest  d where d.network = ?1 and  d.zipCode = ?2 and d.transactionType='A' and d.processed='N' and d.cancelledFlag <> 'Y' ")
	ZipToDest findExistingUnprocessedZipcode(String network, String zipCode);
	
	public boolean existsZipToDestByNetworkAndZipCode(String network, String zipCode);
	
	public boolean existsZipToDestByDestinationTerminal(String destinationTerminal);

}
