package com.fedex.ZDServer.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class ConfigFileReader {

	public String reportConfigPath = System.getProperty("user.dir")+ "\\src\\it\\resources\\configs\\extent-config.xml";
	public static String envFilePath = System.getProperty("user.dir") + "\\src\\it\\resources\\configs\\env.properties";
	public static String dataFilePath = System.getProperty("user.dir") +  "\\src\\it\\resources\\configs\\data.properties";
	
	public static Properties GridAPIProp;
	public static Properties GridAPIPropWrite;
	
	@SuppressWarnings("unused")
	public String getReportConfigPath() {

		if (reportConfigPath != null)
			return reportConfigPath;
		else
			throw new RuntimeException("Report Config Path not specified in the Configuration :reportConfigPath");
	}

	public static void loadProperties() {

		GridAPIProp = new Properties();
		try {
			InputStream fis = new FileInputStream(envFilePath);
			GridAPIProp.load(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	

	
	public static void writeProperties() {
		
		
		try {
			OutputStream output = new FileOutputStream(dataFilePath);
			GridAPIPropWrite = new Properties();
			GridAPIPropWrite.store(output, null);
		}catch (Exception e) {
			e.printStackTrace();
		}

	}
}
