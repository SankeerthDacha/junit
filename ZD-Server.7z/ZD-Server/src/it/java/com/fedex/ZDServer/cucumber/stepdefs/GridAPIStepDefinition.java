package com.fedex.ZDServer.cucumber.stepdefs;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

import static com.fedex.ZDServer.utils.ConfigFileReader.GridAPIProp;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fedex.ZDServer.ServiceValidation.*;

import com.fedex.ZDServer.cucumber.SpringBootBaseIntegrationTest;

@Ignore
public class GridAPIStepDefinition extends SpringBootBaseIntegrationTest{

	Response response;
	ValidatableResponse json;
	
	public static Logger log = LoggerFactory.getLogger(GridAPIStepDefinition.class.getName()); 
	
    @Given("^The base URI is up and running$")
    public void the_base_URI_is_up_and_running() {
        
    	RestAssured.baseURI = GridAPIProp.getProperty("DatagridAPI.lcl.get");
    	log.info("Base URL is up and Running: " + GridAPIProp.getProperty("DatagridAPI.lcl.get"));
    }
    
    @Then("^User should see the status code (\\d+)$")
	public void user_should_see_the_status_code(int statuscode) {
   	
		json = response.then().assertThat().statusCode(statuscode);
		json.log().all().extract();
				
	}
    
    @When("^User verifies \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" for first json \"([^\"]*)\"$")
    public void user_verifies_json(String network, String countryCode,
    		String zipcode, String state, String destination, String creation_user, int row) {
        
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().get();
    	
    	String network_json = response.jsonPath().getString("network["+row+"]");
    	System.out.println("Network  is: "+network_json);
    	assertEquals(network, network_json);
    	
    	String country_json = response.jsonPath().getString("countryCode["+row+"]");
    	System.out.println("country code is: "+country_json);
    	assertEquals(countryCode, country_json);
    	
    	String zip = response.jsonPath().getString("zipCode["+row+"]");
    	System.out.println("Zip code is: "+zip);
    	assertEquals(zipcode,zip);
    	
    	String state_json = response.jsonPath().getString("state["+row+"]");
    	System.out.println("State is: "+state_json);
    	assertEquals(state,state_json);
    	
    	String dest = response.jsonPath().getString("destinationTerminal["+row+"]");
    	System.out.println("destionation is: "+dest);
    	assertEquals(destination, dest);
    	
    	String creation_user_json = response.jsonPath().getString("creationUser["+row+"]");
    	System.out.println("Creation User is: "+creation_user_json);
    	assertEquals(creation_user, creation_user_json);	
    	
    	
    	
    }
    
    @When("^user performs invalid request$")
	public void user_perform_invalid_request() {
   	
       response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().get(GridAPIProp.getProperty("GridAPIInvalidParameter"));
    
	}
    
    @Given("^The base URI is up and running for Add API$")
    public void the_base_URI_is_up_and_running_add() {
        
    	RestAssured.baseURI = GridAPIProp.getProperty("DatagridAPI.lcl.post");
    	
    }
    
    @When("^User sends create request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_sends_create_request_with_body(String countryCode, String creationUser, String destination,
			String effectiveDate, String network, String state, String zipcode) {
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(AddAPIDetails.createAddRequest(countryCode, creationUser, destination, effectiveDate, network,state,zipcode)).when()
				.post(Resources.create_request);
		
	}
    
    @When("^User sends create request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" no comma json$")
	public void user_sends_create_request_with_body_no_comma_json(String countryCode, String creationUser, int destination,
			String effectiveDate, String network, String state, int zipcode) {
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(AddAPIDetails.createAddRequestNoComma(countryCode, creationUser, destination, effectiveDate, network,state,zipcode)).when()
				.post(Resources.create_request);  	
		
	}
    
    @When("^User edit request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
   	public void user_edit_request_with_body(String destination,
   			String effectiveDate, String network, String zipfrom, String zipto) {
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(ModifyAPIDetails.editRequest(destination, effectiveDate, network,zipfrom,zipto)).when()
				.put(Resources.edit_request);  
       	
   	}
    
    @Given("^The base URI is up and running for Modify API$")
    public void the_base_URI_is_up_and_running_modify() {
        
    	RestAssured.baseURI = GridAPIProp.getProperty("DatagridAPI.lcl.put");
    	
    }
    
    @When("^User edit request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" for invalid data$")
   	public void user_edit_request_with_body_invalid(String destination,
   			String effectiveDate, String network, String zipfrom, String zipto) {
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(ModifyAPIDetails.editRequest(destination, effectiveDate, network,zipfrom,zipto)).when()
				.put(Resources.edit_request);  
       	
   	}
    
    @Given("^The base URI is up and running for Delete API$")
    public void the_base_URI_is_up_and_running_delete() {
        
    	RestAssured.baseURI = GridAPIProp.getProperty("DatagridAPI.lcl.delete");
    	
    }
    
    @When("^User delete request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
   	public void user_delete_request_with_body(String effectiveDate, String network, String zipfrom, String zipto) {
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(DeleteAPIDetails.deleteRequest(effectiveDate, network,zipfrom,zipto)).when()
				.delete(Resources.delete_request);  
       	
   	}
    
    @When("^User delete request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" for invaid data$")
   	public void user_delete_request_with_body_invalid(String effectiveDate, String network, String zipfrom, String zipto) {
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(DeleteAPIDetails.deleteRequestInvalidData(effectiveDate, network,zipfrom,zipto)).when()
				.delete(Resources.delete_request);  
       	
   	}
    
}