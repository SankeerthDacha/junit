package com.fedex.ZDServer.ServiceValidation;

public class ModifyAPIDetails {
	
	/**
	 * method: editRequest
	 * @param destination
	 * @param effectiveDate
	 * @param network
	 * @param zipfrom
	 * @param zipto
	 * @return
	 */
	public static String editRequest(String destination,
			String effectiveDate, String network, String zipfrom, String zipto) {
		
		String modify= "{   \r\n" + 
				"    \"destinationTerminal\":\""+destination+"\",\r\n" + 
				"    \"effectiveDate\":\""+effectiveDate+"\",\r\n" +
				"    \"network\":\""+network+"\",\r\n" +
				"    \"zipFrom\":\""+zipfrom+"\",\r\n" +
				"    \"zipTo\":\""+zipto+"\"\r\n" +
				"}";
		return modify;
		
	}
	
	/**
	 * method: editRequestNoComma
	 * @param destination
	 * @param effectiveDate
	 * @param network
	 * @param zipfrom
	 * @param zipto
	 * @return
	 */
	public static String editRequestNoComma(String destination,
			String effectiveDate, String network, String zipfrom, String zipto) {
		
		String modify= "{   \r\n" + 
				"    \"destinationTerminal\":\""+destination+"\",\r\n" + 
				"    \"effectiveDate\":\""+effectiveDate+"\",\r\n" +
				"    \"network\":\""+network+"\"\r\n" +
				"    \"zipFrom\":\""+zipfrom+"\"\r\n" +
				"    \"zipTo\":\""+zipto+"\"\r\n" +
				"}";
		return modify;
		
	}


	
}
