package com.fedex.ZDServer.ServiceValidation;

public class Resources {
	
	// Add ZD Record
	public static final String create_request = "/zipToDest/addZipToDestRecord";
	
	//Modify ZD Record
	public static final String edit_request = "/zipToDest/modifyZDRecord";
	
	//Delete ZD Record
	public static final String delete_request = "/zipToDest/deleteZDRecord";

	
}
