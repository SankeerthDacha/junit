package com.fedex.ZDServer.ServiceValidation;

public class DeleteAPIDetails {
	
	/**
	 * method: deleteRequest
	 * @param destination
	 * @param effectiveDate
	 * @param network
	 * @param zipfrom
	 * @param zipto
	 * @return
	 */
	public static String deleteRequest(String effectiveDate, String network, String zipfrom, String zipto) {
		
		String delete= "{   \r\n" + 
				"    \"effectiveDate\":\""+effectiveDate+"\",\r\n" +
				"    \"network\":\""+network+"\",\r\n" +
				"    \"zipFrom\":\""+zipfrom+"\",\r\n" +
				"    \"zipTo\":\""+zipto+"\"\r\n" +
				"}";
		return delete;
		
	}
	
	/**
	 * method: deleteRequest
	 * @param destination
	 * @param effectiveDate
	 * @param network
	 * @param zipfrom
	 * @param zipto
	 * @return
	 */
	public static String deleteRequestInvalidData(String effectiveDate, String network, String zipfrom, String zipto) {
		
		String delete= "{   \r\n" + 
				"    \"effectiveDate\":\""+effectiveDate+"\",\r\n" +
				"    \"network\":\""+network+"\"\r\n" +
				"    \"zipFrom\":\""+zipfrom+"\"\r\n" +
				"    \"zipTo\":\""+zipto+"\"\r\n" +
				"}";
		return delete;
		
	}
	
}
