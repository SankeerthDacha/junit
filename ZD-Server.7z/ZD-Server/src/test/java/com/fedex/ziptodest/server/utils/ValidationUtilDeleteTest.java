package com.fedex.ziptodest.server.utils;

import static org.junit.Assert.assertEquals;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.server.model.ZipToDestDeleteRequest;
import com.fedex.ziptodest.server.repository.ZipToDestRepository;

@RunWith(SpringRunner.class)
public class ValidationUtilDeleteTest {

	@InjectMocks
	ValidationUtil validationUtil;

	@Mock
	ZipToDestRepository zipToDestRepository;

	@Test
	public void validateDeleteRequestTest() {
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		zipToDestDeleteRequest.setNetwork("FXGL");
		zipToDestDeleteRequest.setZipFrom("10101");
		zipToDestDeleteRequest.setZipTo("10102");
		zipToDestDeleteRequest.setEffectiveDate("2021-12-30.12:00:00");
		zipToDestDeleteRequest.setTimeZone("(GMT-8:00) Canada/Pacific");

		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());

		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		Mockito.doReturn(true).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());

		Mockito.doReturn(true).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		assertEquals(ZipToDestConstants.RECORDS_NOT_PROCESSED,
				validationUtil.validateDeleteRequest(zipToDestDeleteRequest));
	}

	@Test
	public void validateDeleteReq_InvalidEffectiveDate() {
		String output;
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		zipToDestDeleteRequest.setNetwork("FXGL");
		zipToDestDeleteRequest.setZipTo("12345");
		zipToDestDeleteRequest.setEffectiveDate(null);

		output = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);

		assertEquals(ZipToDestConstants.INVALID_DATE_FUTURE, output);
	}

	@Test
	public void validateDeleteReq_InvalidNetwork() {
		String output;
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		zipToDestDeleteRequest.setNetwork(StringUtils.EMPTY);
		zipToDestDeleteRequest.setZipTo("12345");

		output = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);

		assertEquals(ZipToDestConstants.INVALID_NETWORK, output);
	}

	@Test
	public void validateDeleteReq_ZipcodeRangeNotExist() {
		String output;
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		zipToDestDeleteRequest.setNetwork("FXGL");
		zipToDestDeleteRequest.setZipFrom("10101");
		zipToDestDeleteRequest.setZipTo("10102");
		zipToDestDeleteRequest.setEffectiveDate("2021-12-30.12:00:00");
		zipToDestDeleteRequest.setTimeZone("(GMT-8:00) Canada/Pacific");

		Mockito.doReturn(false).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());

		Mockito.doReturn(false).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());
		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		output = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);
		assertEquals(ZipToDestConstants.RECORDS_NOT_PROCESSED, output);

		Mockito.doReturn(true).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());

		Mockito.doReturn(false).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());
		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		output = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);

		assertEquals(ZipToDestConstants.RECORDS_NOT_PROCESSED, output);

		Mockito.doReturn(false).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());

		Mockito.doReturn(true).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());
		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		output = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);

		assertEquals(ZipToDestConstants.RECORDS_NOT_PROCESSED, output);
	}

	/*
	 * @Test public void validateDeleteRequest_isZipcodeRangeUnprocessed() { String
	 * output; ZipToDestDeleteRequest zipToDestDeleteRequest = new
	 * ZipToDestDeleteRequest(); zipToDestDeleteRequest.setNetwork("LPN");
	 * zipToDestDeleteRequest.setZipFrom("12345");
	 * zipToDestDeleteRequest.setZipTo("12345");
	 * zipToDestDeleteRequest.setEffectiveDate("2021-12-30.12:00:00");
	 * zipToDestDeleteRequest.setTimeZone("(GMT-8:00) Canada/Pacific");
	 * 
	 * ZipToDest obj = new ZipToDest(); obj.setNetwork("FXGL");
	 * 
	 * List<ZipToDest> list = new ArrayList<>(); list.add(obj);
	 * 
	 * Mockito.doReturn(list).when(zipToDestRepository).
	 * findProcessedZipcodeBetweenTwoRange( zipToDestDeleteRequest.getZipFrom(),
	 * zipToDestDeleteRequest.getZipTo(), zipToDestDeleteRequest.getNetwork());
	 * 
	 * 
	 * Mockito.doReturn(Collections.EMPTY_LIST).when(zipToDestRepository).
	 * findUnprocessedDeleteTransactions( zipToDestDeleteRequest.getZipFrom(),
	 * zipToDestDeleteRequest.getZipTo(), zipToDestDeleteRequest.getNetwork());
	 * 
	 * Mockito.doReturn(Collections.EMPTY_LIST).when(zipToDestRepository).
	 * findUnprocessedModifyTransactions( zipToDestDeleteRequest.getZipFrom(),
	 * zipToDestDeleteRequest.getZipTo(), zipToDestDeleteRequest.getNetwork());
	 * 
	 * output = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);
	 * 
	 * assertEquals(ZipToDestConstants.UNPROCESSED_TRANSACTIONS, output);
	 * 
	 * }
	 */
	@Test
	public void validateDeleteRequest_invalidEffectiveDate() {
		String output;
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		zipToDestDeleteRequest.setNetwork("LPN");
		zipToDestDeleteRequest.setZipFrom("12345");
		zipToDestDeleteRequest.setZipTo("12345");
		zipToDestDeleteRequest.setEffectiveDate(StringUtils.EMPTY);

		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());

		Mockito.doReturn(true).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipFrom());

		validationUtil.isZipCodeExists(zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		Mockito.doReturn(true).when(zipToDestRepository).existsZipToDestByNetworkAndZipCode(
				zipToDestDeleteRequest.getNetwork(), zipToDestDeleteRequest.getZipTo());

		output = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);

		assertEquals(ZipToDestConstants.INVALID_DATE_FUTURE, output);

		zipToDestDeleteRequest.setEffectiveDate("2020-10-01");

		output = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);
		assertEquals(ZipToDestConstants.RECORDS_NOT_PROCESSED, output);

		zipToDestDeleteRequest.setEffectiveDate(StringUtils.EMPTY);
		zipToDestDeleteRequest.setTimeZone("(GMT-8:00) Canada/Pacific");
		output = validationUtil.validateDeleteRequest(zipToDestDeleteRequest);
		assertEquals(ZipToDestConstants.INVALID_DATE_FUTURE, output);

	}

}
