package com.fedex.ziptodest.server.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.server.model.ZipToDestAddRequest;
import com.fedex.ziptodest.server.repository.ZipToDestRepository;

@RunWith(SpringRunner.class)
public class ValidationUtilAddTest {

	@InjectMocks
	ValidationUtil validationUtil;

	@Mock
	ZipToDestRepository zipToDestRepository;

	/*
	 * @Mock DestinationService destinationService;
	 */

	@Test
	public void testValidateAddReq_positive() {
		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setNetwork("FHGL");
		zipToDestAddRequest.setZipCode("12345");
		zipToDestAddRequest.setCountryCode(840);
		zipToDestAddRequest.setDestinationTerminal("0011");
		zipToDestAddRequest.setEffectiveDate("2020-10-01.12:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-8:00) Canada/Pacific");

		assertNotNull(zipToDestAddRequest.getNetwork());
		assertNotNull(zipToDestAddRequest.getZipCode());

		Mockito.doReturn(false).when(zipToDestRepository)
				.existsZipToDestByNetworkAndZipCode(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		//Mockito.doReturn(true).when(destinationService).isDestinationExist("0011");

		validationUtil.isZipCodeExists(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		assertEquals(ZipToDestConstants.VALID, validationUtil.validateAddRequest(zipToDestAddRequest));

		zipToDestAddRequest.setZipCode("A0A0A0");
		Mockito.doReturn(false).when(zipToDestRepository)
				.existsZipToDestByNetworkAndZipCode(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());
		assertEquals(ZipToDestConstants.VALID, validationUtil.validateAddRequest(zipToDestAddRequest));
	}

	@Test
	public void testValidateAddReqInvalidZipcode() {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setNetwork(StringUtils.EMPTY);
		zipToDestAddRequest.setZipCode(StringUtils.EMPTY);

		assertEquals(ZipToDestConstants.INVALID_NETWORK, validationUtil.validateAddRequest(zipToDestAddRequest));

		zipToDestAddRequest.setNetwork("FHGL");
		assertEquals(ZipToDestConstants.INVALID_ZIPCODE, validationUtil.validateAddRequest(zipToDestAddRequest));

		zipToDestAddRequest.setNetwork("FHGL");
		zipToDestAddRequest.setZipCode("12345");

		assertNotNull(zipToDestAddRequest.getNetwork());
		assertNotNull(zipToDestAddRequest.getZipCode());

		Mockito.doReturn(true).when(zipToDestRepository)
				.existsZipToDestByNetworkAndZipCode(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		validationUtil.isZipCodeExists(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		validationUtil.validateAddRequest(zipToDestAddRequest);
	}

	@Test
	public void testValidateAddReqInvalidDestination() {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setNetwork("FHGL");
		zipToDestAddRequest.setZipCode("12345");
		zipToDestAddRequest.setCountryCode(840);
		zipToDestAddRequest.setDestinationTerminal("12345");
		zipToDestAddRequest.setEffectiveDate("2020-10-01.12:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-8:00) Canada/Pacific");

		assertNotNull(zipToDestAddRequest.getNetwork());
		assertNotNull(zipToDestAddRequest.getZipCode());

		Mockito.doReturn(true).when(zipToDestRepository)
				.existsZipToDestByNetworkAndZipCode(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		validationUtil.isZipCodeExists(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		String output = validationUtil.validateAddRequest(zipToDestAddRequest);

		assertEquals(ZipToDestConstants.INVALID_DESTINATION, output);
	}

	@Test
	public void testValidateAddReqDestinationNotExists() {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setNetwork("FHGL");
		zipToDestAddRequest.setZipCode("12345");
		zipToDestAddRequest.setCountryCode(840);
		zipToDestAddRequest.setDestinationTerminal("0011");
		zipToDestAddRequest.setEffectiveDate("2020-10-01.12:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-8:00) Canada/Pacific");

		String expectedOutput = String.format(ZipToDestConstants.DESTINATION_NOT_EXISTS,
				zipToDestAddRequest.getDestinationTerminal());

		assertNotNull(zipToDestAddRequest.getNetwork());
		assertNotNull(zipToDestAddRequest.getZipCode());

		Mockito.doReturn(false).when(zipToDestRepository)
				.existsZipToDestByNetworkAndZipCode(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		//Mockito.doReturn(false).when(destinationService).isDestinationExist("0011");

		validationUtil.isZipCodeExists(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		String output = validationUtil.validateAddRequest(zipToDestAddRequest);

		assertNotEquals(expectedOutput, output);
	}

	@Test
	public void testValidateAddReqBlankEffectiveDate() {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setNetwork("FHGL");
		zipToDestAddRequest.setZipCode("12345");
		zipToDestAddRequest.setCountryCode(840);
		zipToDestAddRequest.setDestinationTerminal("0011");
		zipToDestAddRequest.setEffectiveDate(null);
		zipToDestAddRequest.setTimeZone("(GMT-8:00) Canada/Pacific");

		assertNotNull(zipToDestAddRequest.getNetwork());
		assertNotNull(zipToDestAddRequest.getZipCode());

		Mockito.doReturn(false).when(zipToDestRepository)
				.existsZipToDestByNetworkAndZipCode(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

	//	Mockito.doReturn(true).when(destinationService).isDestinationExist("0011");

		validationUtil.isZipCodeExists(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		String output = validationUtil.validateAddRequest(zipToDestAddRequest);

		assertEquals(ZipToDestConstants.INVALID_DATE_FUTURE, output);
	}

	@Test
	public void testValidateAddReqInvalidEffectiveDate() {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setNetwork("FHGL");
		zipToDestAddRequest.setZipCode("12345");
		zipToDestAddRequest.setCountryCode(840);
		zipToDestAddRequest.setDestinationTerminal("0011");
		zipToDestAddRequest.setEffectiveDate("2020-10-01");
		zipToDestAddRequest.setTimeZone("(GMT-8:00) Canada/Pacific");

		assertNotNull(zipToDestAddRequest.getNetwork());
		assertNotNull(zipToDestAddRequest.getZipCode());

		Mockito.doReturn(false).when(zipToDestRepository)
				.existsZipToDestByNetworkAndZipCode(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		//Mockito.doReturn(true).when(destinationService).isDestinationExist("0011");

		validationUtil.isZipCodeExists(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		String output = validationUtil.validateAddRequest(zipToDestAddRequest);

		assertEquals(ZipToDestConstants.INVALID_DATE_FUTURE, output);
	}

	@Test
	public void testValidateAddReqInvalidFutureDate() {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setNetwork("FHGL");
		zipToDestAddRequest.setZipCode("12345");
		zipToDestAddRequest.setCountryCode(840);
		zipToDestAddRequest.setDestinationTerminal("0011");
		zipToDestAddRequest.setEffectiveDate("2018-10-01.12:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-8:00) Canada/Pacific");

		assertNotNull(zipToDestAddRequest.getNetwork());
		assertNotNull(zipToDestAddRequest.getZipCode());

		Mockito.doReturn(false).when(zipToDestRepository)
				.existsZipToDestByNetworkAndZipCode(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		//Mockito.doReturn(true).when(destinationService).isDestinationExist("0011");

		validationUtil.isZipCodeExists(zipToDestAddRequest.getNetwork(), zipToDestAddRequest.getZipCode());

		String output = validationUtil.validateAddRequest(zipToDestAddRequest);

		assertEquals(ZipToDestConstants.INVALID_DATE, output);
	}
}
