package com.fedex.ziptodest.server.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.server.exception.ApplicationException;
import com.fedex.ziptodest.server.model.ZipToDest;
import com.fedex.ziptodest.server.model.ZipToDestAddRequest;
import com.fedex.ziptodest.server.model.ZipToDestCancelRequest;
import com.fedex.ziptodest.server.model.ZipToDestDeleteRequest;
import com.fedex.ziptodest.server.model.ZipToDestModifyRequest;
import com.fedex.ziptodest.server.model.ZipToDestNotProcessed;
import com.fedex.ziptodest.server.repository.ZipToDestRepository;
import com.fedex.ziptodest.server.utils.ValidationUtil;
import com.fedex.ziptodest.server.utils.ZipToDestConstants;

@RunWith(SpringRunner.class)
public class ZDServiceImplTest {

	@InjectMocks
	private ZDServiceImpl zDServiceImpl;

	private static ZipToDestRepository zipToDestRepository;

	@Mock
	private EntityManagerFactory entityManagerFactory;

	@Mock
	private EntityManager entityManager;

	@Mock
	private EntityTransaction entityTransaction;

	@Mock
	private ValidationUtil validationUtil;

	@BeforeClass
	public static void setUp() {
		zipToDestRepository = Mockito.mock(ZipToDestRepository.class);
		// zDServiceImpl = Mockito.mock(ZDServiceImpl.class);
	}

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAllZDRecord_Positive() {

		List<ZipToDest> allZDData = new ArrayList<ZipToDest>();
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(123);
		zipToDest.setCancelledFlag('N');
		zipToDest.setCreationUser("Smith");
		zipToDest.setDestinationTerminal("LPN");
		allZDData.add(zipToDest);
		Mockito.doReturn(allZDData).when(zipToDestRepository).findAll();
		zDServiceImpl.getAllZDRecord();
		assertEquals(123, zipToDest.getCountryCode());
		assertEquals('N', zipToDest.getCancelledFlag());
		assertEquals("Smith", zipToDest.getCreationUser());
		assertEquals("LPN", zipToDest.getDestinationTerminal());
	}

	@Test
	public void testGetAllZDRecord_Negative() {

		List<ZipToDest> allZDData = new ArrayList<ZipToDest>();
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(123);
		zipToDest.setCancelledFlag('N');
		zipToDest.setCreationUser("Smith");
		zipToDest.setDestinationTerminal("LPN");
		allZDData.add(zipToDest);
		Mockito.doReturn(allZDData).when(zipToDestRepository).findAll();
		zDServiceImpl.getAllZDRecord();
		assertNotEquals(124, zipToDest.getCountryCode());
		assertNotEquals('Y', zipToDest.getCancelledFlag());
		assertNotEquals("Smit", zipToDest.getCreationUser());
		assertNotEquals("LPZ", zipToDest.getDestinationTerminal());
	}

	@Test
	public void testAddZDRecord_Positive() throws ParseException {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setCountryCode(123);
		zipToDestAddRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-5:00) America/New_York");
		zipToDestAddRequest.setNetwork("FXG");
		zipToDestAddRequest.setZipCode("10000");
		zipToDestAddRequest.setDestinationTerminal("1234");
		zipToDestAddRequest.setState("PA");
		ZipToDest addZDRecord = new ZipToDest();
		Mockito.doReturn(addZDRecord).when(zipToDestRepository).save(addZDRecord);
		zDServiceImpl.addZDRecord(zipToDestAddRequest);
		assertEquals(123, zipToDestAddRequest.getCountryCode());
		assertEquals("2019-08-22.10:00:00", zipToDestAddRequest.getEffectiveDate());
		assertEquals("(GMT-5:00) America/New_York", zipToDestAddRequest.getTimeZone());
		assertEquals("FXG", zipToDestAddRequest.getNetwork());
		assertEquals("10000", zipToDestAddRequest.getZipCode());
		assertEquals("1234", zipToDestAddRequest.getDestinationTerminal());

	}

	@Test
	public void testAddZDRecord_Negative() throws ParseException {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setCountryCode(123);
		zipToDestAddRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-5:00) America/New_York");
		zipToDestAddRequest.setNetwork("FXG");
		zipToDestAddRequest.setZipCode("10000");
		zipToDestAddRequest.setDestinationTerminal("1234");
		zipToDestAddRequest.setState("PA");
		ZipToDest addZDRecord = new ZipToDest();
		Mockito.doReturn(addZDRecord).when(zipToDestRepository).save(addZDRecord);
		zDServiceImpl.addZDRecord(zipToDestAddRequest);
		assertNotEquals(124, zipToDestAddRequest.getCountryCode());
		assertNotEquals("2019-09-22.10:00:00", zipToDestAddRequest.getEffectiveDate());
		assertNotEquals("New_York", zipToDestAddRequest.getTimeZone());
		assertNotEquals("FXL", zipToDestAddRequest.getNetwork());
		assertNotEquals("1000", zipToDestAddRequest.getZipCode());
		assertNotEquals("1235", zipToDestAddRequest.getDestinationTerminal());

	}

	@Test(expected = ApplicationException.class)
	public void testAddZDRecord_catch() throws ParseException {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setEffectiveDate(null);
		ZipToDest addZDRecord = new ZipToDest();
		Mockito.doReturn(addZDRecord).when(zipToDestRepository).save(addZDRecord);
		zDServiceImpl.addZDRecord(zipToDestAddRequest);
	}

	@Test
	public void testModifyRecords_Positive() throws ApplicationException, ParseException {
		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal("1234");
		zipToDestModifyRequest.setEffectiveDate("2022-10-01 12:00:00.40");
		zipToDestModifyRequest.setNetwork("FXG");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) America/New_York");
		zipToDestModifyRequest.setZipFrom("10000");
		zipToDestModifyRequest.setZipTo("20000");

		when(validationUtil.isDateFormatValid("2022-10-01 12:00:00.40")).thenReturn("Valid");
		when(validationUtil.isValidUsaZipCode(Mockito.anyString())).thenReturn(true);

		when(zipToDestRepository.findProcessedZipcodeBetweenTwoRange(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(getMatchedList());
		when(validationUtil.isValidDestination(zipToDestModifyRequest.getDestinationTerminal())).thenReturn(true);

		final SimpleDateFormat effectiveDateFormat = new SimpleDateFormat(ZipToDestConstants.EFFECTIVE_DATE_FORMAT);
		Date formatedDate = effectiveDateFormat.parse("2022-10-01.12:00:00");
		Timestamp ts = new java.sql.Timestamp(formatedDate.getTime());
		when(validationUtil.convertDateToTimeStamp(Mockito.anyString())).thenReturn(ts);
		String s = zDServiceImpl.modifyRecords(zipToDestModifyRequest);
		System.out.println("value of S" + s);
		assertEquals("1234", zipToDestModifyRequest.getDestinationTerminal());
		assertEquals("2022-10-01 12:00:00.40", zipToDestModifyRequest.getEffectiveDate());
		assertEquals("FXG", zipToDestModifyRequest.getNetwork());
		assertEquals("(GMT-5:00) America/New_York", zipToDestModifyRequest.getTimeZone());
		assertEquals("10000", zipToDestModifyRequest.getZipFrom());
		assertEquals("20000", zipToDestModifyRequest.getZipTo());
	}

	@Test
	public void testModifyRecords_NegativeDateFormat() throws ParseException {
		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal("1234");
		zipToDestModifyRequest.setEffectiveDate("2022-10-01");
		zipToDestModifyRequest.setNetwork("FXG");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) America/New_York");
		zipToDestModifyRequest.setZipFrom("10000");
		zipToDestModifyRequest.setZipTo("20000");

		Mockito.doReturn(ZipToDestConstants.INVALID).when(validationUtil)
				.isDateFormatValid(zipToDestModifyRequest.getEffectiveDate());
		zDServiceImpl.modifyRecords(zipToDestModifyRequest);

	}

	@Test
	public void testModifyRecords_Negative() throws ApplicationException, ParseException {
		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal("1234");
		zipToDestModifyRequest.setEffectiveDate("2022-10-01 12:00:00.40");
		zipToDestModifyRequest.setNetwork("FXG");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) America/New_York");
		zipToDestModifyRequest.setZipFrom("10000");
		zipToDestModifyRequest.setZipTo("20000");

		when(validationUtil.isDateFormatValid("2022-10-01 12:00:00.40")).thenReturn("Valid");

		when(zipToDestRepository.findProcessedZipcodeBetweenTwoRange(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(getMatchedList());

		zDServiceImpl.modifyRecords(zipToDestModifyRequest);

		assertNotEquals("1238", zipToDestModifyRequest.getDestinationTerminal());
		assertNotEquals("2021-10-01 12:00:00.40", zipToDestModifyRequest.getEffectiveDate());
		assertNotEquals("FXL", zipToDestModifyRequest.getNetwork());
		assertNotEquals("(GMT-9:00) America/New_York", zipToDestModifyRequest.getTimeZone());
		assertNotEquals("1000", zipToDestModifyRequest.getZipFrom());
		assertNotEquals("2000", zipToDestModifyRequest.getZipTo());

	}

	@Test
	public void testModifyRecords_InvalidZipCodes_Positive() throws ApplicationException, ParseException {

		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal("1234");
		zipToDestModifyRequest.setEffectiveDate("2022-10-01 12:00:00.40");
		zipToDestModifyRequest.setNetwork("FXG");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) America/New_York");
		zipToDestModifyRequest.setZipFrom("1000");
		zipToDestModifyRequest.setZipTo("2000");
		when(validationUtil.isDateFormatValid("2022-10-01 12:00:00.40")).thenReturn("Valid");
		when(zipToDestRepository.findProcessedZipcodeBetweenTwoRange(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(null);
		when(validationUtil.validateModifyRequest(zipToDestModifyRequest)).thenReturn("Valid");
		assertEquals("1234", zipToDestModifyRequest.getDestinationTerminal());
		assertEquals("2022-10-01 12:00:00.40", zipToDestModifyRequest.getEffectiveDate());
		assertEquals("FXG", zipToDestModifyRequest.getNetwork());
		assertEquals("(GMT-5:00) America/New_York", zipToDestModifyRequest.getTimeZone());
		assertEquals("1000", zipToDestModifyRequest.getZipFrom());
		assertEquals("2000", zipToDestModifyRequest.getZipTo());

	}

	@Test
	public void testModifyRecords_InvalidZipCodes_Negative() throws ApplicationException, ParseException {

		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal("1234");
		zipToDestModifyRequest.setEffectiveDate("2022-10-01 12:00:00.40");
		zipToDestModifyRequest.setNetwork("FXG");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) America/New_York");
		zipToDestModifyRequest.setZipFrom("1000");
		zipToDestModifyRequest.setZipTo("2000");
		when(validationUtil.isDateFormatValid("2022-10-01 12:00:00.40")).thenReturn("Valid");
		when(zipToDestRepository.findProcessedZipcodeBetweenTwoRange(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(null); //
		zDServiceImpl.modifyRecords(zipToDestModifyRequest);
		assertNotEquals("1235", zipToDestModifyRequest.getDestinationTerminal());
		assertNotEquals("2021-10-01 12:00:00.40", zipToDestModifyRequest.getEffectiveDate());
		assertNotEquals("FXL", zipToDestModifyRequest.getNetwork());
		assertNotEquals("(GMT-7:00) America/New_York", zipToDestModifyRequest.getTimeZone());
		assertNotEquals("100000", zipToDestModifyRequest.getZipFrom());
		assertNotEquals("20000", zipToDestModifyRequest.getZipTo());

	}

	@Test
	public void testDeleteRecords() throws ParseException {
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		zipToDestDeleteRequest.setEffectiveDate("2022-10-01 12:00:00.40");
		zipToDestDeleteRequest.setNetwork("FXG");
		zipToDestDeleteRequest.setTimeZone("(GMT-5:00) America/New_York");
		zipToDestDeleteRequest.setZipFrom("10000");
		zipToDestDeleteRequest.setZipTo("");
		when(validationUtil.isDateFormatValid("2022-10-01 12:00:00.40")).thenReturn("Valid");

		when(zipToDestRepository.findProcessedZipcodeBetweenTwoRange(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(null);

		zDServiceImpl.deleteRecords(zipToDestDeleteRequest);
	}

	@Test
	public void testDeleteRecords_InvalidDateFormat() throws ParseException {
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		zipToDestDeleteRequest.setEffectiveDate("2022-10-01");
		zipToDestDeleteRequest.setNetwork("FXG");

		Mockito.doReturn(ZipToDestConstants.INVALID).when(validationUtil)
				.isDateFormatValid(zipToDestDeleteRequest.getEffectiveDate());

		zDServiceImpl.deleteRecords(zipToDestDeleteRequest);

	}

	@Test
	public void testDeleteRecords_IsValidUsaZipCode() throws ParseException {
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		zipToDestDeleteRequest.setEffectiveDate("2022-10-01");
		zipToDestDeleteRequest.setNetwork("FXG");
		zipToDestDeleteRequest.setZipFrom("10000");
		zipToDestDeleteRequest.setZipTo("20000");

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil)
				.isDateFormatValid(zipToDestDeleteRequest.getEffectiveDate());

		Mockito.doReturn(true).when(validationUtil).isValidUsaZipCode(zipToDestDeleteRequest.getZipFrom());
		Mockito.doReturn(true).when(validationUtil).isValidUsaZipCode(zipToDestDeleteRequest.getZipTo());

		zDServiceImpl.deleteRecords(zipToDestDeleteRequest);

	}

	/*
	 * @Test public void testDeleteRecords_IsValidUsaZipCodeCondition() throws
	 * ParseException { ZipToDestDeleteRequest zipToDestDeleteRequest = new
	 * ZipToDestDeleteRequest();
	 * zipToDestDeleteRequest.setEffectiveDate("2022-10-01");
	 * zipToDestDeleteRequest.setNetwork("FXG");
	 * zipToDestDeleteRequest.setZipFrom("10000");
	 * zipToDestDeleteRequest.setZipTo("20000");
	 * 
	 * Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil)
	 * .isDateFormatValid(zipToDestDeleteRequest.getEffectiveDate());
	 * 
	 * Mockito.doReturn(true).when(validationUtil).isValidUsaZipCode(
	 * zipToDestDeleteRequest.getZipTo());
	 * 
	 * zDServiceImpl.deleteRecords(zipToDestDeleteRequest);
	 * 
	 * }
	 */

	@Test
	public void testGetNotProcessedZDRecord_Positive() {

		List<ZipToDest> zipToDestList = new ArrayList<>();

		List<ZipToDestNotProcessed> listNotProcessedZDRecord = new ArrayList<>();

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setProcessed('N');
		zipToDest.setUuid("123");
		zipToDest.setZipCode("12301");

		ZipToDest zipToDest1 = new ZipToDest();
		zipToDest1.setProcessed('N');
		zipToDest1.setUuid("123");
		zipToDest1.setZipCode("12301");

		ZipToDestNotProcessed zipToDestNotProcessed = new ZipToDestNotProcessed(zipToDest);
		zipToDestNotProcessed.setZipTo(zipToDestNotProcessed.getZipFrom());

		zipToDestList.add(zipToDest);
		zipToDestList.add(zipToDest1);
		listNotProcessedZDRecord.add(zipToDestNotProcessed);

		Mockito.doReturn(zipToDestList).when(zipToDestRepository).findZipToDestNotProcessed();

		when(zDServiceImpl.getNotProcessedZDRecords()).thenReturn(listNotProcessedZDRecord);

		Mockito.doReturn(zipToDestList).when(zipToDestRepository).findZipToDestNotProcessed();

		when(zDServiceImpl.getNotProcessedZDRecords()).thenReturn(listNotProcessedZDRecord);

		assertEquals('N', zipToDest.getProcessed());
		assertEquals("123", zipToDest.getUuid());
		assertEquals("12301", zipToDest.getZipCode());
		assertEquals('N', zipToDest1.getProcessed());
		assertEquals("123", zipToDest1.getUuid());
		assertEquals("12301", zipToDest1.getZipCode());
		assertNotNull("ZipToDest Uuid must not be null. ", zipToDest.getUuid());
		assertNotNull("ZipToDest Zip Code must not be null. ", zipToDest.getZipCode());
		assertEquals('N', zipToDestNotProcessed.getProcessed());
		assertNotNull("ZipToDestNotProcessed Uuid must not be null. ", zipToDestNotProcessed.getUuid());
		assertNotNull("ZipToDestNotProcessed fromZipCode must not be null. ", zipToDestNotProcessed.getZipFrom());
		assertNotNull("ZipToDestNotProcessed toZipCode must not be null. ", zipToDestNotProcessed.getZipTo());

	}

	@Test
	public void testGetNotProcessedZDRecord_Negative() {

		List<ZipToDest> zipToDestList = new ArrayList<>();

		List<ZipToDestNotProcessed> listNotProcessedZDRecord = new ArrayList<>();

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setProcessed('N');
		zipToDest.setUuid("123");
		zipToDest.setZipCode("12301");

		ZipToDest zipToDest1 = new ZipToDest();
		zipToDest.setProcessed('N');
		zipToDest.setUuid("123");
		zipToDest.setZipCode("12301");

		ZipToDestNotProcessed zipToDestNotProcessed = new ZipToDestNotProcessed(zipToDest);
		zipToDestNotProcessed.setZipTo(zipToDestNotProcessed.getZipFrom());

		zipToDestList.add(zipToDest);
		zipToDestList.add(zipToDest1);
		listNotProcessedZDRecord.add(zipToDestNotProcessed);

		Mockito.doReturn(zipToDestList).when(zipToDestRepository).findZipToDestNotProcessed();

		when(zDServiceImpl.getNotProcessedZDRecords()).thenReturn(listNotProcessedZDRecord);

		Mockito.doReturn(zipToDestList).when(zipToDestRepository).findZipToDestNotProcessed();

		when(zDServiceImpl.getNotProcessedZDRecords()).thenReturn(listNotProcessedZDRecord);

		assertNotEquals('Y', zipToDest.getProcessed());
		assertNotEquals("121", zipToDest.getUuid());
		assertNotEquals("12401", zipToDest.getZipCode());
		assertNotEquals('Y', zipToDest1.getProcessed());
		assertNotEquals("122", zipToDest1.getUuid());
		assertNotEquals("1231", zipToDest1.getZipCode());
		assertNotNull("ZipToDest Uuid must not be null. ", zipToDest.getUuid());
		assertNotNull("ZipToDest Zip Code must not be null. ", zipToDest.getZipCode());
		assertEquals('N', zipToDestNotProcessed.getProcessed());
		assertNotNull("ZipToDestNotProcessed Uuid must not be null. ", zipToDestNotProcessed.getUuid());
		assertNotNull("ZipToDestNotProcessed fromZipCode must not be null. ", zipToDestNotProcessed.getZipFrom());
		assertNotNull("ZipToDestNotProcessed toZipCode must not be null. ", zipToDestNotProcessed.getZipTo());

	}

	private List<ZipToDest> getMatchedList() {

		ZipToDest zipToDest = new ZipToDest();

		zipToDest.setCountryCode(1);
		zipToDest.setCreationDate(new Timestamp(System.currentTimeMillis()));
		zipToDest.setCreationUser("Fedex");
		zipToDest.setCurrent('N');
		zipToDest.setEffectiveDate(new Timestamp(System.currentTimeMillis()));
		zipToDest.setNetwork("FXG");
		zipToDest.setTransactionType('A');
		zipToDest.setZipCode("1234");
		zipToDest.setState("PA");
		zipToDest.setDestinationTerminal("888");

		ZipToDest zipToDest2 = new ZipToDest();
		zipToDest2.setNetwork("FXu");

		ZipToDest zipToDest3 = new ZipToDest();
		zipToDest3.setNetwork("FXX");

		ZipToDest zipToDest4 = new ZipToDest();
		zipToDest4.setNetwork("FXD");

		ZipToDest zipToDest5 = new ZipToDest();
		zipToDest5.setNetwork("FXA");

		ZipToDest zipToDest6 = new ZipToDest();
		zipToDest6.setNetwork("FXZ");

		ZipToDest zipToDest7 = new ZipToDest();
		zipToDest7.setNetwork("FXo");

		ZipToDest zipToDest8 = new ZipToDest();
		zipToDest8.setNetwork("FXp");

		ZipToDest zipToDest9 = new ZipToDest();
		zipToDest9.setNetwork("FXB");

		ZipToDest zipToDest10 = new ZipToDest();
		zipToDest10.setNetwork("FXB");

		ZipToDest zipToDest11 = new ZipToDest();
		zipToDest11.setNetwork("FXW");

		ZipToDest zipToDest12 = new ZipToDest();
		zipToDest12.setNetwork("FXQ");

		List<ZipToDest> matchedList = new ArrayList<ZipToDest>();
		matchedList.add(zipToDest12);
		matchedList.add(zipToDest11);
		matchedList.add(zipToDest10);
		matchedList.add(zipToDest9);
		matchedList.add(zipToDest8);
		matchedList.add(zipToDest7);
		matchedList.add(zipToDest6);
		matchedList.add(zipToDest5);
		matchedList.add(zipToDest4);
		matchedList.add(zipToDest3);
		matchedList.add(zipToDest2);
		matchedList.add(zipToDest);

		return matchedList;

	}

	@Test
	public void testCancelNotProcessedZDRecord_Positive() {

		List<ZipToDest> zipToDestList = new ArrayList<>();
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		List<String> uuid = new ArrayList<>();
		uuid.add("1235");

		ZipToDestCancelRequest zipToDestCancelRequest = new ZipToDestCancelRequest();
		zipToDestCancelRequest.setUser("FedExUsr001");
		zipToDestCancelRequest.setUuid(uuid);

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setProcessed('N');
		zipToDest.setUuid("1235");
		zipToDest.setZipCode("12301");
		zipToDest.setCancelledFlag('Y');
		zipToDest.setCancelledTimestamp(timestamp);
		zipToDest.setCancelledUser("FedexUsr01");

		zipToDestList.add(zipToDest);

		Mockito.doReturn(zipToDestList).when(zipToDestRepository).findZipToDestByProcessedAndUuid("1235");

		when(zDServiceImpl.cancelZipToDestNotProcessed(zipToDestCancelRequest)).thenReturn(1);

		assertEquals('N', zipToDest.getProcessed());
		assertEquals('Y', zipToDest.getCancelledFlag());
		assertEquals("1235", zipToDest.getUuid());
		assertEquals("12301", zipToDest.getZipCode());
		// assertEquals("FedexUsr01",zipToDest.getCancelledUser());
		// assertEquals(new
		// Timestamp(System.currentTimeMillis()),zipToDest.getCancelledTimestamp());
		assertNotNull("ZipToDest Uuid must not be null. ", zipToDest.getUuid());
		assertNotNull("ZipToDest Cancelled User must not be null. ", zipToDest.getCancelledUser());
	}

	@Test
	public void testCancelNotProcessedZDRecord_Negative() {

		List<ZipToDest> zipToDestList = new ArrayList<>();

		List<String> uuid = new ArrayList<>();
		uuid.add("1235");

		ZipToDestCancelRequest zipToDestCancelRequest = new ZipToDestCancelRequest();
		zipToDestCancelRequest.setUser("FedExUsr001");
		zipToDestCancelRequest.setUuid(uuid);

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setProcessed('N');
		zipToDest.setUuid("1235");
		zipToDest.setZipCode("12301");
		zipToDest.setCancelledFlag('Y');
		zipToDest.setCancelledUser("FedexUsr01");
		zipToDest.setCancelledTimestamp(validationUtil.getCurrentUTCDateTime());

		zipToDestList.add(zipToDest);

		Mockito.doReturn(zipToDestList).when(zipToDestRepository).findZipToDestByProcessedAndUuid("1235");

		when(zDServiceImpl.cancelZipToDestNotProcessed(zipToDestCancelRequest)).thenReturn(1);

		assertNotEquals('Y', zipToDest.getProcessed());
		assertNotEquals('N', zipToDest.getCancelledFlag());
		assertNotEquals("1245", zipToDest.getUuid());
		assertNotEquals("12311", zipToDest.getZipCode());
		assertNotEquals("FedexUsr01", zipToDest.getCancelledUser());
		assertNotEquals("New York", zipToDest.getCancelledTimestamp());
		assertNotNull("ZipToDest Uuid must not be null. ", zipToDest.getUuid());
		assertNotNull("ZipToDest Cancelled User must not be null. ", zipToDest.getCancelledUser());
	}
}
