package com.fedex.ziptodest.server.controller;

import static org.junit.Assert.assertEquals;

import java.sql.Timestamp;
import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.server.model.ZipToDest;
import com.fedex.ziptodest.server.model.ZipToDestAddRequest;
import com.fedex.ziptodest.server.model.ZipToDestStatusResponse;
import com.fedex.ziptodest.server.service.ZDService;
import com.fedex.ziptodest.server.utils.ValidationUtil;
import com.fedex.ziptodest.server.utils.ZipToDestConstants;

@RunWith(SpringRunner.class)
public class ZipToDestControllerAddTest {
	
	private ZipToDest addZDRecord;
	private ZipToDestAddRequest zipToDestAddRequest;
	
	@InjectMocks
	private ZipToDestController zipToDestController;

	@Mock
	private ZDService zDService;

	@Mock
	private ValidationUtil validationUtil;
	
	@Before
	public void init(){
		addZDRecord = new ZipToDest();
		addZDRecord.setCancelledFlag('N');
		addZDRecord.setCountryCode(840);
		addZDRecord.setCreationDate(new Timestamp(System.currentTimeMillis()));
		addZDRecord.setCreationUser("Fedex01");
		addZDRecord.setCurrent('N');
		addZDRecord.setDestinationTerminal("0011");
		addZDRecord.setEffectiveDate(null);
		addZDRecord.setNetwork("FXGL");
		addZDRecord.setProcessed('N');
		addZDRecord.setState("CA");
		addZDRecord.setTimeZone("(GMT-5:00) Canada/Central");
		addZDRecord.setTransactionType('A');
		addZDRecord.setUuid("XWER-RVFDT-GHFF");
		addZDRecord.setZipCode("45825");
		
		zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setNetwork("FXGL");
		zipToDestAddRequest.setCountryCode(840);
		zipToDestAddRequest.setCreationUser("Fedex01");
		zipToDestAddRequest.setDestinationTerminal("0011");
		zipToDestAddRequest.setEffectiveDate(null);
		zipToDestAddRequest.setNetwork("FXGL");
		zipToDestAddRequest.setState("CA");
		zipToDestAddRequest.setTimeZone("(GMT-5:00) Canada/Central");
		zipToDestAddRequest.setZipCode("45825");
		zipToDestAddRequest.setCountryCode(123);
		zipToDestAddRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-5:00) Canada/Central");
	}

	@Test
	public void testAddZDRecord_Positive() throws ParseException {				

		Mockito.doReturn(addZDRecord).when(zDService).addZDRecord(zipToDestAddRequest);
		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateAddRequest(zipToDestAddRequest);

		ResponseEntity<ZipToDestStatusResponse> response = zipToDestController.addZDRecord(zipToDestAddRequest);

		assertEquals(ZipToDestConstants.RESPONSE_SUCCESS_MSG, response.getBody().getStatus());
	}

	@Test
	public void testAddZDRecord_InvalidNetwork() throws ParseException {
		
		zipToDestAddRequest.setNetwork(StringUtils.EMPTY);		

		Mockito.doReturn(ZipToDestConstants.INVALID_NETWORK).when(validationUtil)
				.validateAddRequest(zipToDestAddRequest);

		ResponseEntity<ZipToDestStatusResponse> response = zipToDestController.addZDRecord(zipToDestAddRequest);

		assertEquals(ZipToDestConstants.INVALID_NETWORK, response.getBody().getMessage());
	}

	@Test
	public void testAddZDRecord_InvalidZipcode() throws ParseException {
		
		zipToDestAddRequest.setNetwork("FXGL");
		zipToDestAddRequest.setZipCode(StringUtils.EMPTY);	

		Mockito.doReturn(ZipToDestConstants.INVALID_ZIPCODE).when(validationUtil)
				.validateAddRequest(zipToDestAddRequest);

		ResponseEntity<ZipToDestStatusResponse> response = zipToDestController.addZDRecord(zipToDestAddRequest);

		assertEquals(ZipToDestConstants.INVALID_ZIPCODE, response.getBody().getMessage());
	}

}
