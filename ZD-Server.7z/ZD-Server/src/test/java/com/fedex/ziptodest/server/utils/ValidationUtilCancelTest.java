package com.fedex.ziptodest.server.utils;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.server.model.ZipToDestCancelRequest;

@RunWith(SpringRunner.class)
public class ValidationUtilCancelTest {
	
	@Test
	public void validateCancelRequestTest(){
		List<String> uuids = Arrays.asList("12345", "3456");
		ZipToDestCancelRequest zipToDestCancelRequest = new ZipToDestCancelRequest();
		zipToDestCancelRequest.setUser("FedEx01");
		zipToDestCancelRequest.setUuid(uuids);
		ValidationUtil validationUtil = new ValidationUtil();
		String output = validationUtil.validateCancelRequest(zipToDestCancelRequest);
		
		assertEquals(ZipToDestConstants.VALID, output);
	}
	
	@Test
	public void validateCancelRequestTest_negative(){
		String output;
		ValidationUtil validationUtil = new ValidationUtil();
		
		List<String> uuids = Arrays.asList(" ", "3456");
		ZipToDestCancelRequest zipToDestCancelRequest = new ZipToDestCancelRequest();	
		
		output = validationUtil.validateCancelRequest(null);
		assertEquals(ZipToDestConstants.INVALID, output);		
				
		output = validationUtil.validateCancelRequest(zipToDestCancelRequest);
		assertEquals(ZipToDestConstants.INVALID_CANCEL_USER, output);
		
		zipToDestCancelRequest.setUser("FedEx");
		output = validationUtil.validateCancelRequest(zipToDestCancelRequest);
		assertEquals(ZipToDestConstants.INVALID_EMPTY_UUID_LIST, output);
		
		zipToDestCancelRequest.setUuid(Collections.emptyList());
		output = validationUtil.validateCancelRequest(zipToDestCancelRequest);
		assertEquals(ZipToDestConstants.INVALID_EMPTY_UUID_LIST, output);
		
		zipToDestCancelRequest.setUuid(uuids);
		output = validationUtil.validateCancelRequest(zipToDestCancelRequest);
		assertEquals(ZipToDestConstants.INVALID_UUID_LIST, output);		
	}

}
