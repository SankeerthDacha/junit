package com.fedex.ziptodest.server.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.server.exception.ApplicationException;
import com.fedex.ziptodest.server.model.ZipToDest;
import com.fedex.ziptodest.server.model.ZipToDestAddRequest;
import com.fedex.ziptodest.server.model.ZipToDestCancelRequest;
import com.fedex.ziptodest.server.model.ZipToDestDeleteRequest;
import com.fedex.ziptodest.server.model.ZipToDestModifyRequest;
import com.fedex.ziptodest.server.model.ZipToDestNotProcessed;
import com.fedex.ziptodest.server.repository.ZipToDestRepository;
import com.fedex.ziptodest.server.service.ZDService;
import com.fedex.ziptodest.server.utils.ValidationUtil;
import com.fedex.ziptodest.server.utils.ZipToDestConstants;

@RunWith(SpringRunner.class)
public class ZipToDestControllerTest {

	@InjectMocks
	private ZipToDestController zipToDestController;

	@Mock
	private ZDService zDService;

	@Mock
	private ValidationUtil validationUtil;

	@Mock
	private ZipToDestRepository zipToDestRepository;

	@Test
	public void testGetAllZDRecord_Positive() {

		List<ZipToDest> allZDRecord = new ArrayList<>();

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(123);
		zipToDest.setCreationUser("Admin");
		zipToDest.setCancelledFlag('Y');
		zipToDest.setCancelledUser("Smith");

		Mockito.doReturn(allZDRecord).when(zDService).getAllZDRecord();

		zipToDestController.getAllZDRecord();

		assertEquals(123, zipToDest.getCountryCode());
		assertEquals("Admin", zipToDest.getCreationUser());
		assertEquals('Y', zipToDest.getCancelledFlag());
		assertEquals("Smith", zipToDest.getCancelledUser());
	}

	@Test
	public void testGetAllZDRecord_Negative() {

		List<ZipToDest> allZDRecord = new ArrayList<>();

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(123);
		zipToDest.setCreationUser("Admin");
		zipToDest.setCancelledFlag('Y');
		zipToDest.setCancelledUser("Smith");
		allZDRecord.add(zipToDest);

		Mockito.doReturn(allZDRecord).when(zDService).getAllZDRecord();

		zipToDestController.getAllZDRecord();

		assertNotEquals(1234, zipToDest.getCountryCode());
		assertNotEquals("Admins", zipToDest.getCreationUser());
		assertNotEquals('N', zipToDest.getCancelledFlag());
		assertNotEquals("Smit", zipToDest.getCancelledUser());
	}

	@Test
	public void testAddZDRecord_Positive() throws ParseException {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setCountryCode(123);
		zipToDestAddRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-5:00) Canada/Central");

		ZipToDest addZDRecord = new ZipToDest();

		Mockito.doReturn(addZDRecord).when(zDService).addZDRecord(zipToDestAddRequest);
		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateAddRequest(zipToDestAddRequest);

		zipToDestController.addZDRecord(zipToDestAddRequest);

		assertEquals(123, zipToDestAddRequest.getCountryCode());
		assertEquals("2019-08-22.10:00:00", zipToDestAddRequest.getEffectiveDate());
		assertEquals("(GMT-5:00) Canada/Central", zipToDestAddRequest.getTimeZone());
	}

	@Test
	public void testAddZDRecord_Negative() throws ParseException {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setCountryCode(123);
		zipToDestAddRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-5:00) Canada/Central");

		ZipToDest addZDRecord = new ZipToDest();

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateAddRequest(zipToDestAddRequest);
		Mockito.doReturn(addZDRecord).when(zDService).addZDRecord(zipToDestAddRequest);

		zipToDestController.addZDRecord(zipToDestAddRequest);

		assertNotEquals(121, zipToDestAddRequest.getCountryCode());
		assertNotEquals("2019-08-21.10:00:00", zipToDestAddRequest.getEffectiveDate());
		assertNotEquals("(GMT-6:00) Canada/Central", zipToDestAddRequest.getTimeZone());
	}

	@Test
	public void testAddZDRecord_Negative2() throws ParseException {

		ZipToDestAddRequest zipToDestAddRequest = new ZipToDestAddRequest();
		zipToDestAddRequest.setCountryCode(123);
		zipToDestAddRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestAddRequest.setTimeZone("(GMT-5:00) Canada/Central");

		ZipToDest addZDRecord = new ZipToDest();

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateAddRequest(zipToDestAddRequest);
		Mockito.doReturn(addZDRecord).when(zDService).addZDRecord(zipToDestAddRequest);

		zipToDestController.addZDRecord(zipToDestAddRequest);

		assertNotEquals(121, zipToDestAddRequest.getCountryCode());
		assertNotEquals("2019-08-21.10:00:00", zipToDestAddRequest.getEffectiveDate());
		assertNotEquals("(GMT-6:00) Canada/Central", zipToDestAddRequest.getTimeZone());
	}

	@Test
	public void testModifyZDRecord_Positive() throws ApplicationException, ParseException {
		String response = "success";

		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal("321");
		zipToDestModifyRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) Canada/Central");
		zipToDestModifyRequest.setZipFrom("10000");
		zipToDestModifyRequest.setZipTo("10000");

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(123);

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateModifyRequest(zipToDestModifyRequest);
		assertEquals("321", zipToDestModifyRequest.getDestinationTerminal());
		assertEquals("2019-08-22.10:00:00", zipToDestModifyRequest.getEffectiveDate());
		assertEquals("(GMT-5:00) Canada/Central", zipToDestModifyRequest.getTimeZone());
		assertEquals("10000", zipToDestModifyRequest.getZipFrom());
		assertEquals("10000", zipToDestModifyRequest.getZipTo());

	}

	@Test
	public void testModifyZDRecord_IfCondition() throws ParseException {

		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal("321");
		zipToDestModifyRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) Canada/Central");
		zipToDestModifyRequest.setZipFrom("10000");
		zipToDestModifyRequest.setZipTo("10000");

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(123);

		Mockito.doReturn(ZipToDestConstants.INVALID).when(validationUtil).validateModifyRequest(zipToDestModifyRequest);

		zipToDestController.modifyZDRecord(zipToDestModifyRequest);

	}

	@Test
	public void testModifyZDRecord_IfCondition1() throws ParseException {

		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal(null);
		zipToDestModifyRequest.setEffectiveDate("2019-08-22");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) ");
		zipToDestModifyRequest.setZipFrom(null);
		zipToDestModifyRequest.setZipTo("10000");

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateModifyRequest(zipToDestModifyRequest);

		Mockito.doReturn(null).when(zDService).modifyRecords(zipToDestModifyRequest);

		zipToDestController.modifyZDRecord(zipToDestModifyRequest);

	}

	@Test
	public void testModifyZDRecord_IfCondition2() throws ParseException {

		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal(null);
		zipToDestModifyRequest.setEffectiveDate("2019-08-22");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) ");
		zipToDestModifyRequest.setZipFrom(null);
		zipToDestModifyRequest.setZipTo("10000");

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateModifyRequest(zipToDestModifyRequest);

		Mockito.doReturn("success").when(zDService).modifyRecords(zipToDestModifyRequest);

		zipToDestController.modifyZDRecord(zipToDestModifyRequest);

	}

	@Test
	public void testModifyZDRecord_Negative() throws ApplicationException, ParseException {
		String response = " ";

		ZipToDestModifyRequest zipToDestModifyRequest = new ZipToDestModifyRequest();
		zipToDestModifyRequest.setDestinationTerminal("321");
		zipToDestModifyRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestModifyRequest.setTimeZone("(GMT-5:00) Canada/Central");
		zipToDestModifyRequest.setZipFrom("10000");
		zipToDestModifyRequest.setZipTo("10000");

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(123);

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateModifyRequest(zipToDestModifyRequest);
		Mockito.doReturn(response).when(zDService).modifyRecords(zipToDestModifyRequest);
		zipToDestController.modifyZDRecord(zipToDestModifyRequest);
		assertNotEquals("322", zipToDestModifyRequest.getDestinationTerminal());
		assertNotEquals("2019-03-22.10:00:00", zipToDestModifyRequest.getEffectiveDate());
		assertNotEquals("(GMT-6:00) Canada/Central", zipToDestModifyRequest.getTimeZone());
		assertNotEquals("20000", zipToDestModifyRequest.getZipFrom());
		assertNotEquals("30000", zipToDestModifyRequest.getZipTo());
	}

	@Test
	public void testDeleteZDRecord_Positive() throws ApplicationException, ParseException {
		String response = "success";
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		zipToDestDeleteRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestDeleteRequest.setTimeZone("(GMT-5:00) Canada/Central");
		zipToDestDeleteRequest.setNetwork("FXG");
		zipToDestDeleteRequest.setZipFrom("10000");
		zipToDestDeleteRequest.setZipTo("20000");

		Mockito.doReturn(response).when(zDService).deleteRecords(zipToDestDeleteRequest);
		zipToDestController.deleteZDRecord(zipToDestDeleteRequest);
		assertEquals("2019-08-22.10:00:00", zipToDestDeleteRequest.getEffectiveDate());
		assertEquals("(GMT-5:00) Canada/Central", zipToDestDeleteRequest.getTimeZone());
		assertEquals("FXG", zipToDestDeleteRequest.getNetwork());
		assertEquals("10000", zipToDestDeleteRequest.getZipFrom());
		assertEquals("20000", zipToDestDeleteRequest.getZipTo());
	}

	@Test
	public void testDeleteZDRecord_Negative() throws ApplicationException, ParseException {
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		String response = " ";
		zipToDestDeleteRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestDeleteRequest.setTimeZone("(GMT-5:00) Canada/Central");
		zipToDestDeleteRequest.setNetwork("FXG");
		zipToDestDeleteRequest.setZipFrom("10000");
		zipToDestDeleteRequest.setZipTo("20000");

		Mockito.doReturn(response).when(zDService).deleteRecords(zipToDestDeleteRequest);
		zipToDestController.deleteZDRecord(zipToDestDeleteRequest);
		assertNotEquals("2019-09-22.10:00:00", zipToDestDeleteRequest.getEffectiveDate());
		assertNotEquals("(GMT-6:00) Canada/Central", zipToDestDeleteRequest.getTimeZone());
		assertNotEquals("FXGL", zipToDestDeleteRequest.getNetwork());
		assertNotEquals("1000", zipToDestDeleteRequest.getZipFrom());
		assertNotEquals("2000", zipToDestDeleteRequest.getZipTo());
	}

	@Test
	public void testDeleteZDRecord_Condition() throws ApplicationException, ParseException {
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		String response = " ";
		zipToDestDeleteRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestDeleteRequest.setTimeZone("(GMT-5:00) Canada/Central");
		zipToDestDeleteRequest.setNetwork("FXG");
		zipToDestDeleteRequest.setZipFrom("10000");
		zipToDestDeleteRequest.setZipTo("20000");

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateDeleteRequest(zipToDestDeleteRequest);

		zipToDestController.deleteZDRecord(zipToDestDeleteRequest);

	}

	@Test
	public void testDeleteZDRecord_Condition1() throws ApplicationException, ParseException {
		ZipToDestDeleteRequest zipToDestDeleteRequest = new ZipToDestDeleteRequest();
		String response = " ";
		zipToDestDeleteRequest.setEffectiveDate("2019-08-22.10:00:00");
		zipToDestDeleteRequest.setTimeZone("(GMT-5:00) Canada/Central");
		zipToDestDeleteRequest.setNetwork("FXG");
		zipToDestDeleteRequest.setZipFrom("10000");
		zipToDestDeleteRequest.setZipTo("20000");

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateDeleteRequest(zipToDestDeleteRequest);

		Mockito.doReturn("success").when(zDService).deleteRecords(zipToDestDeleteRequest);

		zipToDestController.deleteZDRecord(zipToDestDeleteRequest);

	}

	@Test
	public void testGetNotProcessedZDRecord_Positive() {

		List<ZipToDestNotProcessed> listNotProcessedZDRecord = new ArrayList<>();

		ZipToDestNotProcessed zipToDest = new ZipToDestNotProcessed();
		zipToDest.setCountryCode(123);
		zipToDest.setCreationUser("Admin");
		zipToDest.setProcessed('N');
		zipToDest.setUuid("1234");
		zipToDest.setZipFrom("234");
		zipToDest.setZipTo("234");

		listNotProcessedZDRecord.add(zipToDest);

		Mockito.doReturn(listNotProcessedZDRecord).when(zDService).getNotProcessedZDRecords();

		zipToDestController.getNotProcessedZDRecord();

		assertEquals(123, zipToDest.getCountryCode());
		assertEquals("Admin", zipToDest.getCreationUser());
		assertEquals('N', zipToDest.getProcessed());
		assertEquals("1234", zipToDest.getUuid());
		assertEquals("234", zipToDest.getZipFrom());
		assertEquals("234", zipToDest.getZipTo());
		assertEquals('N', zipToDest.getProcessed());
		assertNotNull("ZipToDest uuid should  be null", zipToDest.getUuid());
		assertNotNull("ZipToDest fromZipCode should  be null", zipToDest.getZipFrom());
		assertNotNull("ZipToDest toZipCode should  be null", zipToDest.getZipTo());
	}

	@Test
	public void testGetNotProcessedZDRecord_Negative() {

		List<ZipToDestNotProcessed> listNotProcessedZDRecord = new ArrayList<>();

		ZipToDestNotProcessed zipToDest = new ZipToDestNotProcessed();
		zipToDest.setCountryCode(123);
		zipToDest.setCreationUser("Admin");
		zipToDest.setProcessed('N');
		zipToDest.setUuid("1234");
		zipToDest.setZipFrom("234");
		zipToDest.setZipTo("234");

		listNotProcessedZDRecord.add(zipToDest);

		Mockito.doReturn(listNotProcessedZDRecord).when(zDService).getNotProcessedZDRecords();

		zipToDestController.getNotProcessedZDRecord();

		assertNotEquals(124, zipToDest.getCountryCode());
		assertNotEquals("Admins", zipToDest.getCreationUser());
		assertNotEquals('Y', zipToDest.getProcessed());
		assertNotEquals("123", zipToDest.getUuid());
		assertNotEquals("254", zipToDest.getZipFrom());
		assertNotEquals("235", zipToDest.getZipTo());
		assertNotEquals('Y', zipToDest.getProcessed());
		assertNotEquals('Y', zipToDest.getProcessed());
		assertNotNull("ZipToDest uuid should not be null", zipToDest.getUuid());
		assertNotNull("ZipToDest fromZipCode should not be null", zipToDest.getZipFrom());
		assertNotNull("ZipToDest toZipCode should not be null", zipToDest.getZipTo());
	}

	@Test
	public void testCancelZDRecord_Positive() throws ApplicationException {

		ZipToDestCancelRequest zipToDestCancelRequest = new ZipToDestCancelRequest();

		zipToDestCancelRequest.setUser("FedExUsr001");

		List<String> uuid = new ArrayList<>();
		uuid.add("1235");
		zipToDestCancelRequest.setUuid(uuid);

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setZipCode("1301");
		zipToDest.setProcessed('N');
		zipToDest.setUuid("1235");
		zipToDest.setCancelledFlag('Y');
		zipToDest.setCancelledTimestamp(new Timestamp(System.currentTimeMillis()));
		zipToDest.setCancelledUser("FedExUsr001");

		Mockito.doReturn(1).when(zDService).cancelZipToDestNotProcessed(zipToDestCancelRequest);

		Mockito.doReturn("Valid").when(validationUtil).validateCancelRequest(zipToDestCancelRequest);

		zipToDestController.cancelNotProcessedZDRecord(zipToDestCancelRequest);

		assertEquals("1301", zipToDest.getZipCode());
		assertEquals('N', zipToDest.getProcessed());
		assertEquals("1235", zipToDest.getUuid());
		assertEquals('Y', zipToDest.getCancelledFlag());
		assertEquals("FedExUsr001", zipToDest.getCancelledUser());
		assertNotNull("ZipToDest uuid should not be null", zipToDest.getUuid());
		assertNotNull("ZipToDest zipCode should not be null", zipToDest.getZipCode());
		assertNotNull("ZipToDest cancelledUser should not be null", zipToDest.getCancelledUser());
		assertNotNull("ZipToDest cancelledTimestamp should not be null", zipToDest.getCancelledTimestamp());
	}

	@Test
	public void testCancelZDRecord_Negative() throws ApplicationException {

		ZipToDestCancelRequest zipToDestCancelRequest = new ZipToDestCancelRequest();

		zipToDestCancelRequest.setUser("FedExUsr001");

		List<String> uuid = new ArrayList<>();
		uuid.add("1235");
		zipToDestCancelRequest.setUuid(uuid);

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setZipCode("1301");
		zipToDest.setProcessed('N');
		zipToDest.setUuid("1235");
		zipToDest.setCancelledFlag('Y');
		zipToDest.setCancelledTimestamp(new Timestamp(System.currentTimeMillis()));
		zipToDest.setCancelledUser("FedExUsr001");

		Mockito.doReturn(1).when(zDService).cancelZipToDestNotProcessed(zipToDestCancelRequest);

		zipToDestController.cancelNotProcessedZDRecord(zipToDestCancelRequest);

		assertNotEquals("1302", zipToDest.getZipCode());
		assertNotEquals('Y', zipToDest.getProcessed());
		assertNotEquals("1234", zipToDest.getUuid());
		assertNotEquals('N', zipToDest.getCancelledFlag());
		assertNotEquals("Time", zipToDest.getCancelledTimestamp());
		assertNotEquals("FedExUsr002", zipToDest.getCancelledUser());
		assertNotNull("ZipToDest uuid should not be null", zipToDest.getUuid());
		assertNotNull("ZipToDest zipCode should not be null", zipToDest.getZipCode());
		assertNotNull("ZipToDest cancelledUser should not be null", zipToDest.getCancelledUser());
		assertNotNull("ZipToDest cancelledTimestamp should not be null", zipToDest.getCancelledTimestamp());
	}

	@Test
	public void testCancelZDRecord_Condition() throws ApplicationException {

		ZipToDestCancelRequest zipToDestCancelRequest = new ZipToDestCancelRequest();

		zipToDestCancelRequest.setUser("FedExUsr001");

		List<String> uuid = new ArrayList<>();
		uuid.add("1235");
		zipToDestCancelRequest.setUuid(uuid);

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setZipCode("1301");
		zipToDest.setProcessed('N');
		// zipToDest.setUuid(" ");
		zipToDest.setCancelledFlag('Y');
		zipToDest.setCancelledTimestamp(new Timestamp(System.currentTimeMillis()));
		zipToDest.setCancelledUser("FedExUsr001");

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateCancelRequest(zipToDestCancelRequest);

		Mockito.doReturn(0).when(zDService).cancelZipToDestNotProcessed(zipToDestCancelRequest);

		zipToDestController.cancelNotProcessedZDRecord(zipToDestCancelRequest);

	}

	@Test
	public void testCancelZDRecord_Condition1() throws ApplicationException {

		ZipToDestCancelRequest zipToDestCancelRequest = new ZipToDestCancelRequest();

		zipToDestCancelRequest.setUser("FedExUsr001");

		List<String> uuid = new ArrayList<>();
		uuid.add("1235");
		zipToDestCancelRequest.setUuid(uuid);

		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setZipCode("1301");
		zipToDest.setProcessed('N');
		zipToDest.setUuid("354");

		Mockito.doReturn(ZipToDestConstants.VALID).when(validationUtil).validateCancelRequest(zipToDestCancelRequest);

		Mockito.doReturn(1).when(zDService).cancelZipToDestNotProcessed(zipToDestCancelRequest);

		zipToDestController.cancelNotProcessedZDRecord(zipToDestCancelRequest);

	}

}