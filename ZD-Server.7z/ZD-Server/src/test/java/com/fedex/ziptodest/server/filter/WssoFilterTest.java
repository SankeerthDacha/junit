package com.fedex.ziptodest.server.filter;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.server.model.CurrentUser;
import com.fedex.ziptodest.server.model.Department;

@RunWith(SpringRunner.class)
public class WssoFilterTest {
	@InjectMocks
	private WssoFilter wssoFilter;

	@Mock
	private CurrentUser currentuser;

	@Mock
	private Department department;

	/*@Test
	public void testdoFilterInternal() throws ServletException, IOException {

		HttpServletRequest mockReq = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse mockResp = Mockito.mock(HttpServletResponse.class);
		FilterChain mockFilterChain = Mockito.mock(FilterChain.class);
		StringBuffer sb = new StringBuffer("localhost");
		Mockito.when(mockReq.getRequestURL()).thenReturn(sb);
		wssoFilter.doFilterInternal(mockReq, mockResp, mockFilterChain);

		verify(mockFilterChain, times(1)).doFilter(mockReq, mockResp);
	}*/

	@Test
	public void testdoFilterInternal_ForValidRequest_SortationRole() throws ServletException, IOException {

		HttpServletRequest mockReq = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse mockResp = Mockito.mock(HttpServletResponse.class);
		FilterChain mockFilterChain = Mockito.mock(FilterChain.class);
		StringBuffer sb = new StringBuffer("ziptodest");
		Mockito.when(mockReq.getRequestURL()).thenReturn(sb);

		Mockito.when(mockReq.getHeader("OBLIX_UID")).thenReturn("01");
		Mockito.when(mockReq.getHeader("OBLIX_FIRSTNAME")).thenReturn("User1");
		Mockito.when(mockReq.getHeader("OBLIX_LASTNAME")).thenReturn("fedex");
		Mockito.when(mockReq.getHeader("OBLIX_MAIL")).thenReturn("mail@fedex.com");
		Mockito.when(mockReq.getHeader("OBLIX_DEPARTMENTNUMBER")).thenReturn("1490007000");

		Mockito.when(department.getSortationRole()).thenReturn(getSortationRoles());
		wssoFilter.doFilterInternal(mockReq, mockResp, mockFilterChain);
		verify(mockFilterChain, times(1)).doFilter(mockReq, mockResp);
	}

	@Test
	public void testdoFilterInternal_ForValidRequest_VisionManagement() throws ServletException, IOException {

		HttpServletRequest mockReq = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse mockResp = Mockito.mock(HttpServletResponse.class);
		FilterChain mockFilterChain = Mockito.mock(FilterChain.class);
		StringBuffer sb = new StringBuffer("ziptodest");
		Mockito.when(mockReq.getRequestURL()).thenReturn(sb);

		Mockito.when(mockReq.getHeader("OBLIX_UID")).thenReturn("01");
		Mockito.when(mockReq.getHeader("OBLIX_FIRSTNAME")).thenReturn("User1");
		Mockito.when(mockReq.getHeader("OBLIX_LASTNAME")).thenReturn("fedex");
		Mockito.when(mockReq.getHeader("OBLIX_MAIL")).thenReturn("mail@fedex.com");
		Mockito.when(mockReq.getHeader("OBLIX_DEPARTMENTNUMBER")).thenReturn("1492555000");

		Mockito.when(department.getSortationRole()).thenReturn(getVisionRoles());
		wssoFilter.doFilterInternal(mockReq, mockResp, mockFilterChain);
		verify(mockFilterChain, times(1)).doFilter(mockReq, mockResp);
	}

	private List<String> getSortationRoles() {
		List<String> roles = Arrays.asList("1490007000", "300N14000A");
		return roles;
	}

	private List<String> getVisionRoles() {
		List<String> roles = Arrays.asList("1492555000");
		return roles;
	}

}
