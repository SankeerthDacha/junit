package com.fedex.ziptodest.server;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.Charset;
import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)

@ContextConfiguration
@ComponentScan("com.fedex.ZDServer")
@SpringBootTest(classes = ZDServerApplication.class)
@ActiveProfiles("lcl")
@WebAppConfiguration

@RestController
public class ZDServerApplicationTests {
	private static final Logger log = LoggerFactory.getLogger(ZDServerApplicationTests.class);
	private final MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext context;

	private HttpMessageConverter jackson2HttpMessageConverter;

	@Autowired
	void setConverters(HttpMessageConverter<?>[] converters) {
		this.jackson2HttpMessageConverter = Arrays.asList(converters).stream()
				.filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter).findAny().orElse(null);

		assertNotNull("the JSON message converter must not be null", this.jackson2HttpMessageConverter);
	}

	@Before
	public void setup() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}

	@Test
	public void testAliveController() throws Exception {
		mockMvc.perform(get("/aliveTest")).andExpect(status().isOk())
				.andExpect(content().contentType("text/plain;charset=UTF-8"));

	}

	@Test
	public void testZipToDestController() throws Exception {
		mockMvc.perform(get("/current/record/get")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=UTF-8"));

		mockMvc.perform(MockMvcRequestBuilders.get("/ZipToDest").accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound()); // Wrong URL

		mockMvc.perform(
				MockMvcRequestBuilders.get("/current/record/get").accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()); // Correct URL

	}

	@Test
	public void contextLoads() {
	}

}
