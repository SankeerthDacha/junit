package com.fedex.ziptodest.server.model;

import static org.junit.Assert.assertEquals;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.junit.Before;
import org.junit.Test;
/**
 * 
 * @author 3786636
 *
 */

public class ZipToDestTest {

	ZipToDest zipToDest = new ZipToDest();
	Timestamp timeStamp = Timestamp.valueOf(LocalDateTime.now());
	ZipToDestPK zipToDestPK = new ZipToDestPK("FDH", 10, "111", timeStamp);

	@Before
	public void addRecord() {
		zipToDest.setCountryCode(1);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreationDate(timeStamp);
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDate(timeStamp);
		zipToDest.setZipCode("12345");
		zipToDest.setState("PA");
		zipToDest.setProcessed('N');
		zipToDest.setZipFrom("1000");
		zipToDest.setZipTo("2000");
		zipToDest.setTimeZone("(GMT-8:00) Canada/Pacific");
	}

	@Test
	public void testZipToDestRecords() {
		assertEquals(1, zipToDest.getCountryCode());
		assertEquals("FXG", zipToDest.getNetwork());
		assertEquals(timeStamp, zipToDest.getCreationDate());
		assertEquals("Fedex", zipToDest.getCreationUser());
		assertEquals("123", zipToDest.getDestinationTerminal());
		assertEquals(timeStamp, zipToDest.getEffectiveDate());
		assertEquals("12345", zipToDest.getZipCode());
		assertEquals("PA", zipToDest.getState());
		assertEquals('N', zipToDest.getProcessed());
		assertEquals("1000", zipToDest.getZipFrom());
		assertEquals("2000", zipToDest.getZipTo());
		assertEquals("(GMT-8:00) Canada/Pacific", zipToDest.getTimeZone());

		assertEquals("FDH", zipToDestPK.getNetwork());		
		assertEquals(10, zipToDestPK.getCountryCode());
		assertEquals("111", zipToDestPK.getZipCode());
		assertEquals(timeStamp, zipToDestPK.getCreationDate());
	}

}
