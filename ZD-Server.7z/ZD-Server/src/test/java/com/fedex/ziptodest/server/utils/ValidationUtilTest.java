/**
 * 
 */
package com.fedex.ziptodest.server.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.server.model.ZipToDestModifyRequest;

/**
 * @author 3790999
 *
 */
public class ValidationUtilTest {

	ValidationUtil validationUtil = new ValidationUtil();
	ZipToDestModifyRequest zipToDest = new ZipToDestModifyRequest();
	String pattern = "yyyy-MM-dd HH:mm:ss.SS";
	String timeString = "2100-10-01.12:00:00";

	@Before
	public void setInput() {
		zipToDest.setNetwork("FXG");
		zipToDest.setDestinationTerminal("0011");
		zipToDest.setEffectiveDate(timeString);
	}
	

	@Test
	public void testValidateModifyInput() {		
		assertEquals(ZipToDestConstants.INVALID_ZIP_RANGE, validationUtil.validateModifyRequest(zipToDest));
	}
	
	@Test
	public void testValidateModify_InvalidDestination() {
		ZipToDestModifyRequest zipToDest = new ZipToDestModifyRequest();
		zipToDest.setNetwork("FXG");
		zipToDest.setDestinationTerminal("12345");
		zipToDest.setEffectiveDate(timeString);
		assertEquals(ZipToDestConstants.INVALID_DESTINATION, validationUtil.validateModifyRequest(zipToDest));
	}

	@Test
	public void testIsEffectiveDateValid(){	
		Timestamp ts=new Timestamp(System.currentTimeMillis());
		boolean effectiveDate=validationUtil.isEffectiveDateValid(ts);
		assertFalse(effectiveDate);		
	}

	@Test
	public void testValidateModifyInput_InvalidNetwork() {
		zipToDest.setNetwork("");
		String message = validationUtil.validateModifyRequest(zipToDest);
		assertEquals(ZipToDestConstants.INVALID_NETWORK, message);
	}

	@Test
	public void testValidateModifyInput_InvalidDestination() {
		zipToDest.setDestinationTerminal("998768");
		boolean message = validationUtil.isValidDestination(zipToDest.getDestinationTerminal());
		assertFalse(message);
	}

	@Test
	public void testValidateModifyInput_InvalidDate() {
		zipToDest.setEffectiveDate(null);
		String message = validationUtil.validateModifyRequest(zipToDest);
		assertEquals(ZipToDestConstants.INVALID_DATE, message);
	}

	@Test
	public void testIsValidDestination_DestinationEmpty() {
		boolean destinastion = validationUtil.isValidDestination(" ");
		assertFalse(destinastion);
	}

	@Test
	public void testIsValidDestination() {
		boolean destinastion = validationUtil.isValidDestination("1011");
		assertTrue(destinastion);
	}

	@Test
	public void testIsValidDestination_isNumerice() {
		boolean destinastion = validationUtil.isValidDestination("A0A");
		assertFalse(destinastion);
	}	
	
	@Test
	public void testInvalidDestination(){
		boolean isGreaterThan9999 = validationUtil.isValidDestination("12345");
		boolean isLessThanOne = validationUtil.isValidDestination("0");
		assertFalse(isGreaterThan9999);
		assertFalse(isLessThanOne);
	}
	
	@Test
	public void testConvertDateToTimeStamp() throws ParseException {
		assertNotNull(validationUtil.convertDateToTimeStamp("2019-08-22.10:00:00"));
	}

	@Test
	public void testIsDateFormatValid() {
		assertEquals(ZipToDestConstants.VALID, validationUtil.isDateFormatValid("2019-08-22.10:00:00"));		
	}

	@Test
	public void testIsDateFormatValid_Neg() {
		assertEquals(ZipToDestConstants.INVALID, validationUtil.isDateFormatValid("201908.10:00:00"));
	}

}
